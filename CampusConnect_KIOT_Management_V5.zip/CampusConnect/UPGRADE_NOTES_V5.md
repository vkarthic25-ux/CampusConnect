CampusConnect V5 updates

1. Super Admin has a dedicated Create Staff / Faculty button.
2. Staff accounts are created without an admin-chosen password.
3. New staff accounts are stored with accountType=staff and mustSetPassword=true.
4. New faculty/staff accounts automatically appear in the Staff Directory with their department, designation, qualification, subjects and skills.
5. Staff Login now starts with the staff college email.
6. For a newly created staff account, the first login shows Create Staff Password. The staff member creates a personal password with uppercase, lowercase, number and 8+ characters.
7. After first-time password creation, the account becomes a normal Staff Login account and the staff member can sign in with email + the new password.
8. Password setup uses a short-lived server-signed setup session and is cleared after successful password creation.
9. Existing staff/faculty accounts with passwords continue to use the normal staff login flow.
10. Student registration and student login behavior remain unchanged.
11. Admin user-management shows First password pending for staff accounts that have not completed first-time setup.

Setup:
cd CampusConnect\server
npm install
npm run seed
npm run dev

cd CampusConnect\client
npm install
npm run dev
