# CampusConnect – KIOT College Community Portal

A complete MERN college community portal for Knowledge Institute of Technology (KIOT), with MongoDB-backed CRUD and role-based management.

## What is upgraded

- KIOT college logo and college campus banner/background throughout the portal
- Modern dashboard inspired by the supplied KIOT reference design
- Super Admin control center on the dashboard
- Super Admin can create, edit and delete clubs
- Super Admin can create, edit and delete events
- Super Admin can upload club banners and event banners directly from the website
- Club Admin can update their assigned club details and banner
- Club Admin can create, update and delete events belonging to their assigned club
- Faculty can create events and announcements
- Students can join clubs, register for events and manage achievements
- User Management for Super Admin: role update and user deletion
- Announcements with create/delete permissions
- MongoDB persistence for users, clubs, events, achievements, announcements, discussions and notifications
- Seed data so the portal has visible content immediately
- Responsive desktop/tablet/mobile UI
- Backend permissions are enforced by JWT + role checks; frontend buttons are not the security boundary

## Banner uploads

Club and event banners are selected in the web form. The image is converted to a data URL and stored in MongoDB, so no Cloudinary account is required for this local development version.

Keep banner images reasonably sized (a few MB or less) for good performance.

## Folder structure

```text
CampusConnect/
├── client/
│   ├── public/assets/
│   ├── src/
│   └── package.json
├── server/
│   ├── config/
│   ├── controllers/
│   ├── middleware/
│   ├── models/
│   ├── routes/
│   ├── seed.js
│   └── package.json
└── README.md
```

## 1. MongoDB

Install MongoDB locally and open MongoDB Compass with:

```text
mongodb://127.0.0.1:27017
```

Database used by CampusConnect:

```text
campusconnect
```

## 2. Backend

Open Command Prompt / PowerShell:

```cmd
cd "CampusConnect\server"
npm install
npm run seed
npm run dev
```

Backend:

```text
http://localhost:5000
```

## 3. Frontend

Open a second terminal:

```cmd
cd "CampusConnect\client"
npm install
npm run dev
```

Frontend:

```text
http://localhost:5173
```

## 4. Demo accounts

```text
Super Admin
admin@kiot.ac.in
Admin@123

Faculty
faculty@kiot.ac.in
Faculty@123

Club Admin
clubadmin@kiot.ac.in
ClubAdmin@123

Student
student@kiot.ac.in
Student@123
```

## 5. Admin workflow

Login as `admin@kiot.ac.in`.

- Dashboard → use **New Club** or **New Event**
- Clubs → create club, assign faculty/club admin, upload banner, edit/delete
- Events → create event, select club, upload banner, edit/delete
- Users → change roles or delete users
- Announcements → publish and remove announcements

## 6. Club Admin workflow

Login as `clubadmin@kiot.ac.in`.

- Clubs → edit the assigned club and its banner
- Events → create events for the assigned club
- Events → edit/delete events for the assigned club

## 7. Important environment values

Backend `.env`:

```text
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/campusconnect
JWT_SECRET=campusconnect_kiot_super_secret_change_this
JWT_EXPIRES_IN=7d
CLIENT_URL=http://localhost:5173
```

Frontend `.env`:

```text
VITE_API_URL=http://localhost:5000/api
VITE_SOCKET_URL=http://localhost:5000
```

## 8. Reset/reseed development content

Run:

```cmd
cd "CampusConnect\server"
npm run seed
```

The seed uses upsert operations for the sample records, so running it again refreshes the sample users/clubs/events/announcements instead of creating duplicates with the same unique lookup values.


## Fix included in this build

- Fixed club creation/editing when Faculty In-Charge is not selected.
- Empty `incharge` values are converted to `null` before Mongoose validation.
- Club `incharge` is optional with `default: null`.
- Club admin/member/objective/activity arrays are normalized before save.
- Club form now includes an explicit `No faculty assigned` option.
- CRUD responses include consistent `success` fields and clearer API errors.

## Latest Fixes
- Fixed blank/error-prone profile, achievements, notifications and user-management screens with loading/error states and a page error boundary.
- Added clickable profile avatar in the top navigation and sidebar.
- Profile avatar now shows the first letter of the user's name when no profile image is available.
- Upgraded KIOT logo and campus background graphics.
- Club registration now opens a Student Details form and stores the registration in the selected Club document under `memberDetails` while retaining the member ObjectId in `members`.
- Event registration now opens a Student Details form and stores the registration in the selected Event document under `registrationDetails` while retaining the user ObjectId in `registrations`.
- Registration details include full name, college email, roll number, UMIS, department, year, section and phone.
- Successful club/event registration creates an in-app notification.

### Registration storage examples
Club document:
- `members[]` -> registered user ObjectIds
- `memberDetails[]` -> full student registration details

Event document:
- `registrations[]` -> registered user ObjectIds
- `registrationDetails[]` -> full student registration details
