import { Router } from "express";
import { protect } from "../middleware/auth.js";
import { listGroups, joinGroup, messages, sendMessage, members } from "../controllers/peerController.js";

const r = Router();
r.get("/peer-groups", protect, listGroups);
r.post("/peer-groups/:id/join", protect, joinGroup);
r.get("/peer-groups/:id/messages", protect, messages);
r.post("/peer-groups/:id/messages", protect, sendMessage);
r.get("/peer-groups/:id/members", protect, members);
export default r;
