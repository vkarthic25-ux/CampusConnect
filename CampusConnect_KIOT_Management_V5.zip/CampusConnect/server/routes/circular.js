import { Router } from "express";
import { protect } from "../middleware/auth.js";
import { listCirculars, createCircular, updateCircular, deleteCircular, downloadCircular } from "../controllers/circularController.js";

const r = Router();
r.get("/", protect, listCirculars);
r.post("/", protect, createCircular);
r.put("/:id", protect, updateCircular);
r.delete("/:id", protect, deleteCircular);
r.get("/:id/download", protect, downloadCircular);
export default r;
