import { Router } from "express";
import { protect } from "../middleware/auth.js";
import { clubChat, sendClubChat, listResources, downloadResource, createResource, searchAll, listStaff, listStudents, getMyLoginStatus } from "../controllers/extrasController.js";

const r = Router();
r.get("/chat/:clubId", protect, clubChat);
r.post("/chat/:clubId", protect, sendClubChat);
r.get("/resources", protect, listResources);
r.post("/resources", protect, createResource);
r.get("/resources/:id/download", protect, downloadResource);
r.get("/search", protect, searchAll);
r.get("/staff", protect, listStaff);
r.get("/students/connect", protect, listStudents);
r.get("/login-status", protect, getMyLoginStatus);
export default r;
