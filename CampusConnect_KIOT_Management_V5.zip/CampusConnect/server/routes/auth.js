import { Router } from 'express';
import { register, login, me, logout, checkStaffLogin, setFirstStaffPassword } from '../controllers/authController.js';
import { protect } from '../middleware/auth.js';

const r = Router();
r.post('/register', register);
r.post('/login', login);
r.post('/staff/check', checkStaffLogin);
r.post('/staff/set-first-password', setFirstStaffPassword);
r.post('/logout', protect, logout);
r.get('/me', protect, me);
r.post('/forgot-password', (req, res) => res.json({ message: 'If the email exists, reset instructions will be sent.' }));
r.post('/reset-password', (req, res) => res.json({ message: 'Password reset endpoint ready.' }));
export default r;
