import { Router } from "express";
import { protect } from "../middleware/auth.js";
import { myClubMembers } from "../controllers/staffController.js";

const r = Router();
r.get("/club-members", protect, myClubMembers);
export default r;
