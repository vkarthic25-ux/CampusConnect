import Club from "../models/Club.js";
import Event from "../models/Event.js";
import User from "../models/User.js";
import ChatMessage from "../models/ChatMessage.js";
import Resource from "../models/Resource.js";
import Notification from "../models/Notification.js";

const isMember = (club, userId) =>
  club.members?.some((id) => id.toString() === userId.toString()) ||
  club.clubAdmins?.some((id) => id.toString() === userId.toString()) ||
  club.incharge?.toString() === userId.toString();

export async function clubChat(req, res) {
  try {
    const club = await Club.findById(req.params.clubId);
    if (!club) return res.status(404).json({ message: "Club not found" });
    if (!isMember(club, req.user._id) && req.user.role !== "super_admin") {
      return res.status(403).json({ message: "Join this club to access its private chat" });
    }
    const messages = await ChatMessage.find({ club: club._id })
      .populate("sender", "name role profileImage department")
      .sort({ createdAt: 1 })
      .limit(200);
    res.json({ data: messages });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function sendClubChat(req, res) {
  try {
    const club = await Club.findById(req.params.clubId);
    if (!club) return res.status(404).json({ message: "Club not found" });
    if (!isMember(club, req.user._id) && req.user.role !== "super_admin") {
      return res.status(403).json({ message: "Only club members can chat" });
    }
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ message: "Message is required" });
    const doc = await ChatMessage.create({ club: club._id, sender: req.user._id, message });
    const populated = await doc.populate("sender", "name role profileImage department");
    res.status(201).json({ data: populated });
  } catch (e) { res.status(400).json({ message: e.message }); }
}

export async function listResources(req, res) {
  try {
    const { q, department, subject, category } = req.query;
    const filter = {};
    if (department) filter.department = department;
    if (subject) filter.subject = new RegExp(subject, "i");
    if (category) filter.category = category;
    if (q) filter.$or = [
      { title: new RegExp(q, "i") },
      { description: new RegExp(q, "i") },
      { subject: new RegExp(q, "i") },
      { fileName: new RegExp(q, "i") }
    ];
    const data = await Resource.find(filter)
      .select("-fileData")
      .populate("uploadedBy", "name role department profileImage")
      .sort({ createdAt: -1 });
    res.json({ data });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function downloadResource(req, res) {
  try {
    const doc = await Resource.findById(req.params.id);
    if (!doc) return res.status(404).json({ message: "Resource not found" });
    const buffer = Buffer.from(doc.fileData, "base64");
    res.setHeader("Content-Type", doc.mimeType);
    res.setHeader("Content-Disposition", `attachment; filename="${doc.fileName.replace(/"/g, "")}"`);
    res.send(buffer);
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function createResource(req, res) {
  try {
    const { title, description, subject, department, category, fileName, mimeType, fileData, fileSize } = req.body;
    if (!title || !fileName || !mimeType || !fileData) return res.status(400).json({ message: "Title and file are required" });
    if (!mimeType.includes("pdf") && !mimeType.startsWith("text/") && !mimeType.includes("presentation") && !mimeType.includes("word") && !mimeType.includes("document")) {
      return res.status(400).json({ message: "Please upload a study document such as PDF or document file" });
    }
    if (Number(fileSize || 0) > 8 * 1024 * 1024) return res.status(400).json({ message: "File must be 8 MB or smaller" });
    const doc = await Resource.create({ title, description, subject, department, category, fileName, mimeType, fileData: String(fileData).replace(/^data:[^;]+;base64,/, ""), fileSize, uploadedBy: req.user._id });
    const data = await Resource.findById(doc._id).select("-fileData").populate("uploadedBy", "name role department profileImage");
    res.status(201).json({ data });
  } catch (e) { res.status(400).json({ message: e.message }); }
}

export async function searchAll(req, res) {
  try {
    const { q = "", type = "all", department, year, role, category } = req.query;
    const rx = q ? new RegExp(q, "i") : null;
    const result = {};
    if (type === "all" || type === "users") {
      const f = {};
      if (rx) f.$or = [{ name: rx }, { email: rx }, { department: rx }, { skills: rx }, { subjects: rx }];
      if (department) f.department = department;
      if (year) f.year = year;
      if (role) f.role = role;
      result.users = await User.find(f).select("name email role department year section subjects skills profileImage designation qualification").limit(100);
    }
    if (type === "all" || type === "clubs") {
      const f = {};
      if (rx) f.$or = [{ name: rx }, { description: rx }, { category: rx }];
      if (category) f.category = category;
      result.clubs = await Club.find(f).select("name code description category banner members incharge").populate("incharge", "name department profileImage").limit(100);
    }
    if (type === "all" || type === "events") {
      const f = {};
      if (rx) f.$or = [{ title: rx }, { description: rx }, { venue: rx }, { category: rx }];
      if (category) f.category = category;
      result.events = await Event.find(f).select("title description category banner date venue club registrations").populate("club", "name").sort({ date: 1 }).limit(100);
    }
    res.json({ data: result });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function listStaff(req, res) {
  try {
    const { q = "", department = "", designation = "" } = req.query;
    const filter = { role: { $in: ["faculty", "club_admin"] }, isActive: true };
    if (department && department !== "All Departments") filter.department = department;
    if (designation && designation !== "All Designations") filter.designation = new RegExp(designation, "i");
    if (q) {
      const rx = new RegExp(q, "i");
      filter.$or = [
        { name: rx },
        { email: rx },
        { department: rx },
        { designation: rx },
        { subjects: rx },
        { skills: rx },
        { employeeId: rx },
      ];
    }
    const data = await User.find(filter)
      .select("name email role accountType department designation qualification employeeId subjects skills bio profileImage phone")
      .sort({ department: 1, name: 1 });
    res.json({ data, filters: { department: department || "All Departments", q } });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function listStudents(req, res) {
  try {
    const { department, year, subject, skill, q } = req.query;
    const f = { role: "student", isActive: true };
    if (department) f.department = department;
    if (year) f.year = year;
    if (subject) f.subjects = new RegExp(subject, "i");
    if (skill) f.skills = new RegExp(skill, "i");
    if (q) f.$or = [{ name: new RegExp(q, "i") }, { department: new RegExp(q, "i") }, { skills: new RegExp(q, "i") }, { subjects: new RegExp(q, "i") }];
    const data = await User.find(f).select("name email department year section subjects skills profileImage bio batch").sort({ department: 1, year: 1, name: 1 }).limit(200);
    res.json({ data });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function getMyLoginStatus(req, res) {
  res.json({ data: { role: req.user.role, accountType: req.user.role === "student" ? "student" : "staff", lastLoginAt: req.user.lastLoginAt, loginCount: req.user.loginCount } });
}
