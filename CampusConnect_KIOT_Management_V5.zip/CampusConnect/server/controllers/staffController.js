import Club from "../models/Club.js";

export async function myClubMembers(req, res) {
  try {
    if (req.user.role !== "faculty" && req.user.role !== "super_admin") {
      return res.status(403).json({ message: "Only faculty can view club registration members" });
    }

    const filter = req.user.role === "super_admin" ? {} : { incharge: req.user._id };
    const clubs = await Club.find(filter)
      .populate("incharge", "name email department designation profileImage")
      .populate("clubAdmins", "name email department profileImage")
      .sort({ name: 1 });

    res.json({
      data: clubs.map((club) => ({
        _id: club._id,
        name: club.name,
        code: club.code,
        category: club.category,
        description: club.description,
        incharge: club.incharge,
        clubAdmins: club.clubAdmins,
        members: club.members || [],
        memberDetails: club.memberDetails || [],
      })),
    });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}
