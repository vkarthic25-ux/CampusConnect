import Circular from "../models/Circular.js";

const canPublish = (role) => ["super_admin", "faculty", "club_admin"].includes(role);
const canEdit = (req, doc) => req.user.role === "super_admin" || doc.createdBy?.toString() === req.user._id.toString();

const publicFields = "title content audience department attachmentName attachmentType createdBy createdAt updatedAt";

export async function listCirculars(req, res) {
  try {
    const requestedDepartment = String(req.query.department || "").trim();
    const base = {};
    if (requestedDepartment && requestedDepartment !== "All Departments") {
      base.$or = [
        { department: requestedDepartment },
        { department: "All Departments" },
        { department: "" },
        { department: { $exists: false } },
      ];
    }

    const docs = await Circular.find(base)
      .select(publicFields)
      .populate("createdBy", "name role department profileImage")
      .sort({ createdAt: -1 })
      .limit(200);

    const isAdmin = req.user.role === "super_admin";
    const isStudent = req.user.role === "student";
    const userDepartment = String(req.user.department || "").trim();

    const visible = docs.filter((doc) => {
      if (isAdmin) return true;

      const audienceVisible =
        doc.audience === "all" ||
        (doc.audience === "students" && isStudent) ||
        (doc.audience === "staff" && !isStudent);
      if (!audienceVisible) return false;

      const targetDepartment = String(doc.department || "All Departments").trim();
      if (!targetDepartment || targetDepartment === "All Departments") return true;
      return userDepartment && targetDepartment.toLowerCase() === userDepartment.toLowerCase();
    });

    res.json({ data: visible, total: visible.length });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

export async function createCircular(req, res) {
  try {
    if (!canPublish(req.user.role)) {
      return res.status(403).json({ message: "Only staff or super admin can publish circulars" });
    }

    const { title, content, audience = "all", department = "All Departments", attachmentName = "", attachmentType = "", attachmentData = "" } = req.body;
    if (!title?.trim() || !content?.trim()) {
      return res.status(400).json({ message: "Title and circular content are required" });
    }
    if (attachmentData && attachmentData.length > 12 * 1024 * 1024) {
      return res.status(400).json({ message: "Circular attachment is too large. Keep it under 9 MB." });
    }

    const doc = await Circular.create({
      title: title.trim(),
      content: content.trim(),
      audience,
      department: department?.trim() || "All Departments",
      attachmentName,
      attachmentType,
      attachmentData,
      createdBy: req.user._id,
    });

    const saved = await Circular.findById(doc._id).select(publicFields).populate("createdBy", "name role department profileImage");
    res.status(201).json({ data: saved, message: "Circular published successfully" });
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
}

export async function updateCircular(req, res) {
  try {
    const doc = await Circular.findById(req.params.id);
    if (!doc) return res.status(404).json({ message: "Circular not found" });
    if (!canEdit(req, doc)) return res.status(403).json({ message: "You can only update your own circular" });

    const allowed = ["title", "content", "audience", "department", "attachmentName", "attachmentType", "attachmentData"];
    for (const key of allowed) if (req.body[key] !== undefined) doc[key] = req.body[key];
    await doc.save();

    const saved = await Circular.findById(doc._id).select(publicFields).populate("createdBy", "name role department profileImage");
    res.json({ data: saved, message: "Circular updated successfully" });
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
}

export async function deleteCircular(req, res) {
  try {
    const doc = await Circular.findById(req.params.id);
    if (!doc) return res.status(404).json({ message: "Circular not found" });
    if (!canEdit(req, doc)) return res.status(403).json({ message: "You can only delete your own circular" });
    await doc.deleteOne();
    res.json({ message: "Circular deleted successfully" });
  } catch (e) {
    res.status(400).json({ message: e.message });
  }
}

export async function downloadCircular(req, res) {
  try {
    const doc = await Circular.findById(req.params.id).select("attachmentName attachmentType attachmentData");
    if (!doc || !doc.attachmentData) return res.status(404).json({ message: "No attachment found" });
    const buffer = Buffer.from(doc.attachmentData, "base64");
    res.setHeader("Content-Type", doc.attachmentType || "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename="${String(doc.attachmentName || "circular-file").replace(/"/g, "")}"`);
    res.send(buffer);
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}
