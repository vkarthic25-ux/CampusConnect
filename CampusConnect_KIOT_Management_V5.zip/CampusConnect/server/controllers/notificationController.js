import Notification from '../models/Notification.js';
import User from '../models/User.js';

export async function listMine(req,res){
  try {
    const data=await Notification.find({user:req.user._id}).sort({createdAt:-1}).limit(100);
    res.json({data});
  } catch(e) { res.status(500).json({message:e.message}); }
}

export async function markRead(req,res){
  try {
    const n=await Notification.findOneAndUpdate({_id:req.params.id,user:req.user._id},{isRead:true},{new:true});
    if(!n)return res.status(404).json({message:'Notification not found'});
    res.json({data:n});
  } catch(e) { res.status(500).json({message:e.message}); }
}

export async function markAll(req,res){
  try {
    await Notification.updateMany({user:req.user._id,isRead:false},{isRead:true});
    res.json({message:'All notifications marked as read'});
  } catch(e) { res.status(500).json({message:e.message}); }
}

export async function sendNotification(req,res){
  try {
    if(req.user.role !== 'super_admin') return res.status(403).json({message:'Only Super Admin can send notifications'});
    const {title='',message='',audience='all',department='All Departments',userId=''}=req.body||{};
    if(!String(title).trim() || !String(message).trim()) return res.status(400).json({message:'Title and message are required'});

    const filter = { isActive:true };
    if(userId){
      filter._id = userId;
    } else if(audience==='students') {
      filter.role='student';
    } else if(audience==='staff') {
      filter.role={$in:['faculty','club_admin','super_admin']};
    }
    if(department && department !== 'All Departments') filter.department=department;

    const recipients = await User.find(filter).select('_id');
    if(!recipients.length) return res.status(404).json({message:'No matching active users found'});

    const docs = recipients.map(({_id})=>({
      user:_id,
      title:String(title).trim(),
      message:String(message).trim(),
      type:'admin',
    }));
    await Notification.insertMany(docs);
    res.status(201).json({message:`Notification sent to ${docs.length} user${docs.length===1?'':'s'}.`,count:docs.length});
  } catch(e) {
    res.status(500).json({message:e.message});
  }
}
