import bcrypt from 'bcryptjs';
import crypto from 'crypto';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import generateToken from '../utils/generateToken.js';
import LoginActivity from '../models/LoginActivity.js';

const isKIOT = (e) => /^[^\s@]+@kiot\.ac\.in$/i.test(e || '');
const isStrongPassword = (p) => typeof p === 'string' && p.length >= 8 && /[A-Z]/.test(p) && /[a-z]/.test(p) && /[0-9]/.test(p);
const safe = (u) => ({
  id: u._id,
  _id: u._id,
  name: u.name,
  email: u.email,
  role: u.role,
  accountType: u.accountType || (u.role === 'student' ? 'student' : 'staff'),
  profileImage: u.profileImage,
  phone: u.phone,
  department: u.department,
  year: u.year,
  section: u.section,
  rollNo: u.rollNo,
  umis: u.umis,
  batch: u.batch,
  subjects: u.subjects,
  skills: u.skills,
  bio: u.bio,
  designation: u.designation,
  qualification: u.qualification,
  employeeId: u.employeeId,
  isVerified: u.isVerified,
  mustSetPassword: !!u.mustSetPassword,
  lastLoginAt: u.lastLoginAt,
  loginCount: u.loginCount
});

function createSetupToken(user) {
  const token = jwt.sign(
    { id: user._id.toString(), purpose: 'staff-first-password' },
    process.env.JWT_SECRET,
    { expiresIn: '15m' }
  );
  user.passwordSetupTokenHash = crypto.createHash('sha256').update(token).digest('hex');
  user.passwordSetupExpires = new Date(Date.now() + 15 * 60 * 1000);
  return token;
}

export async function register(req, res) {
  try {
    const { name, email, password, phone, department, year, section, rollNo, umis, batch, subjects, skills } = req.body;
    if (!name || !email || !password) return res.status(400).json({ message: 'Name, email and password are required' });
    if (!isKIOT(email)) return res.status(400).json({ message: 'Only @kiot.ac.in email addresses are allowed' });
    if (!isStrongPassword(password)) return res.status(400).json({ message: 'Password must contain 8+ characters, uppercase, lowercase and number' });
    if (await User.findOne({ email: email.toLowerCase() })) return res.status(409).json({ message: 'Email already registered' });

    const hash = await bcrypt.hash(password, 12);
    const u = await User.create({
      name,
      email: email.toLowerCase(),
      password: hash,
      phone,
      department,
      year,
      section,
      rollNo,
      umis,
      batch,
      subjects: Array.isArray(subjects) ? subjects : [],
      skills: Array.isArray(skills) ? skills : [],
      role: 'student',
      accountType: 'student',
      mustSetPassword: false
    });
    u.lastLoginAt = new Date();
    u.loginCount = 1;
    await u.save();
    await LoginActivity.create({ user: u._id, accountType: 'student', role: u.role, ipAddress: req.ip, userAgent: req.get('user-agent') || '' });
    res.status(201).json({ message: 'Student registration successful', data: { user: safe(u), token: generateToken(u) } });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

export async function checkStaffLogin(req, res) {
  try {
    const { email } = req.body;
    if (!isKIOT(email)) return res.status(400).json({ message: 'Use your @kiot.ac.in college email.' });

    const user = await User.findOne({ email: email.toLowerCase().trim() });
    if (!user || user.role === 'student') {
      return res.status(404).json({ message: 'No staff account was found for this email.' });
    }
    if (!user.isActive) return res.status(403).json({ message: 'This staff account is inactive. Contact the administrator.' });

    if (user.mustSetPassword) {
      const setupToken = createSetupToken(user);
      await user.save();
      return res.json({
        message: 'First-time staff account detected. Create your password to continue.',
        requiresPasswordSetup: true,
        setupToken,
        user: { name: user.name, email: user.email, department: user.department, designation: user.designation }
      });
    }

    return res.json({ requiresPasswordSetup: false, message: 'Staff account found. Enter your password.' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

export async function setFirstStaffPassword(req, res) {
  try {
    const { email, password, confirmPassword, setupToken } = req.body;
    if (!isKIOT(email)) return res.status(400).json({ message: 'Use your @kiot.ac.in college email.' });
    if (!setupToken) return res.status(400).json({ message: 'Staff password setup session is missing. Start staff login again.' });
    if (!isStrongPassword(password)) return res.status(400).json({ message: 'Password must contain 8+ characters, uppercase, lowercase and number' });
    if (password !== confirmPassword) return res.status(400).json({ message: 'Passwords do not match.' });

    let decoded;
    try {
      decoded = jwt.verify(setupToken, process.env.JWT_SECRET);
    } catch {
      return res.status(401).json({ message: 'Password setup session expired. Start staff login again.' });
    }
    if (decoded.purpose !== 'staff-first-password') return res.status(401).json({ message: 'Invalid staff password setup session.' });

    const tokenHash = crypto.createHash('sha256').update(setupToken).digest('hex');
    const user = await User.findOne({
      _id: decoded.id,
      email: email.toLowerCase().trim(),
      role: { $ne: 'student' },
      mustSetPassword: true,
      passwordSetupTokenHash: tokenHash,
      passwordSetupExpires: { $gt: new Date() }
    });

    if (!user) return res.status(401).json({ message: 'Staff password setup session is invalid or expired.' });
    if (!user.isActive) return res.status(403).json({ message: 'This staff account is inactive. Contact the administrator.' });

    user.password = await bcrypt.hash(password, 12);
    user.mustSetPassword = false;
    user.passwordSetupTokenHash = '';
    user.passwordSetupExpires = null;
    await user.save();

    return res.json({ message: 'Password created successfully. You can now sign in as Staff.' });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

export async function login(req, res) {
  try {
    const { email, password, accountType } = req.body;
    if (!isKIOT(email)) return res.status(400).json({ message: 'Only @kiot.ac.in email addresses are allowed' });
    if (!['student', 'staff'].includes(accountType)) return res.status(400).json({ message: 'Select Student or Staff before signing in' });

    const u = await User.findOne({ email: email.toLowerCase().trim() });
    if (!u || !(await bcrypt.compare(password || '', u.password))) return res.status(401).json({ message: 'Invalid email or password' });
    if (!u.isActive) return res.status(403).json({ message: 'This account is inactive. Contact the administrator.' });
    const actualType = u.role === 'student' ? 'student' : 'staff';
    if (actualType !== accountType) return res.status(403).json({ message: `This account is registered as ${actualType}. Select ${actualType} login.` });
    if (u.mustSetPassword) return res.status(403).json({ message: 'Create your staff password first using Staff Login.' });

    u.accountType = actualType;
    u.lastLoginAt = new Date();
    u.loginCount = (u.loginCount || 0) + 1;
    await u.save();
    await LoginActivity.create({ user: u._id, accountType: actualType, role: u.role, ipAddress: req.ip, userAgent: req.get('user-agent') || '' });
    res.json({ message: 'Login successful', data: { user: safe(u), token: generateToken(u) } });
  } catch (e) {
    res.status(500).json({ message: e.message });
  }
}

export async function me(req, res) { res.json({ data: { user: safe(req.user) } }); }
export async function logout(req, res) { res.json({ message: 'Logged out successfully' }); }
