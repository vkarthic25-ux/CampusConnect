import bcrypt from "bcryptjs";
import crypto from "crypto";
import Achievement from "../models/Achievement.js";
import Club from "../models/Club.js";
import Event from "../models/Event.js";
import Announcement from "../models/Announcement.js";
import Discussion from "../models/Discussion.js";
import User from "../models/User.js";
import Notification from "../models/Notification.js";

const map = {
  achievements: Achievement,
  clubs: Club,
  events: Event,
  announcements: Announcement,
  discussions: Discussion,
  users: User,
};

const isAdmin = (req) => req.user?.role === "super_admin";

const canManageClub = (req, club) => {
  if (isAdmin(req)) return true;
  if (req.user?.role !== "club_admin") return false;

  const userId = req.user._id.toString();
  const isClubAdmin = (club.clubAdmins || []).some(
    (x) => x.toString() === userId
  );
  const isIncharge =
    club.incharge && club.incharge.toString() === userId;

  return isClubAdmin || isIncharge;
};

const canManageEvent = async (req, event) => {
  if (isAdmin(req)) return true;
  if (req.user?.role !== "club_admin") return false;

  const club = event.club ? await Club.findById(event.club) : null;
  return !!club && canManageClub(req, club);
};

export async function list(req, res) {
  try {
    const resource = req.params.resource;
    const M = map[resource];

    if (!M) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }

    let query = M.find();

    if (resource === "achievements") {
      query = query.populate(
        "user",
        "name email profileImage department year"
      );
    }

    if (resource === "clubs") {
      query = query
        .populate(
          "incharge",
          "name email profileImage department year"
        )
        .populate(
          "clubAdmins",
          "name email profileImage department year"
        )
        .populate(
          "members",
          "name email profileImage department year"
        )
        .populate(
          "memberDetails.user",
          "name email profileImage department year"
        );
    }

    if (resource === "events") {
      query = query
        .populate("club", "name logo banner category")
        .populate("createdBy", "name profileImage role")
        .populate(
          "facultyCoordinator",
          "name email profileImage department"
        )
        .populate("registrations", "name profileImage")
        .populate("registrationDetails.user", "name email profileImage department year");
    }

    if (resource === "announcements") {
      query = query.populate(
        "createdBy",
        "name profileImage role"
      );
    }

    if (resource === "discussions") {
      query = query
        .populate("author", "name profileImage")
        .populate("comments.user", "name profileImage");
    }

    if (resource === "users") {
      query = query.select("-password");
    }

    const data = await query.sort({ createdAt: -1 }).limit(200);

    return res.json({
      success: true,
      data,
    });
  } catch (error) {
    console.error("List error:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function getOne(req, res) {
  try {
    const resource = req.params.resource;
    const M = map[resource];

    if (!M) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }

    let query = M.findById(req.params.id);

    if (resource === "clubs") {
      query = query
        .populate(
          "incharge",
          "name email profileImage department year"
        )
        .populate(
          "clubAdmins",
          "name email profileImage department year"
        )
        .populate(
          "members",
          "name email profileImage department year"
        )
        .populate(
          "memberDetails.user",
          "name email profileImage department year"
        );
    }

    if (resource === "events") {
      query = query
        .populate("club", "name logo banner category")
        .populate("createdBy", "name profileImage role")
        .populate(
          "facultyCoordinator",
          "name email profileImage department"
        )
        .populate("registrations", "name profileImage")
        .populate("registrationDetails.user", "name email profileImage department year");
    }

    if (resource === "achievements") {
      query = query.populate("user", "name email profileImage");
    }

    if (resource === "announcements") {
      query = query.populate(
        "createdBy",
        "name profileImage role"
      );
    }

    if (resource === "discussions") {
      query = query
        .populate("author", "name profileImage")
        .populate("comments.user", "name profileImage");
    }

    const doc = await query;

    if (!doc) {
      return res.status(404).json({
        success: false,
        message: "Not found",
      });
    }

    return res.json({
      success: true,
      data: doc,
    });
  } catch (error) {
    console.error("Get one error:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}

export async function create(req, res) {
  try {
    const resource = req.params.resource;

    if (resource === "users" && !isAdmin(req)) {
      return res.status(403).json({
        success: false,
        message: "Only super admin can create users",
      });
    }

    if (resource === "clubs" && !isAdmin(req)) {
      return res.status(403).json({
        success: false,
        message: "Only super admin can create clubs",
      });
    }

    if (
      resource === "events" &&
      !["super_admin", "club_admin", "faculty"].includes(
        req.user.role
      )
    ) {
      return res.status(403).json({
        success: false,
        message: "You cannot create events",
      });
    }

    if (
      resource === "announcements" &&
      !["super_admin", "club_admin", "faculty"].includes(
        req.user.role
      )
    ) {
      return res.status(403).json({
        success: false,
        message: "You cannot create announcements",
      });
    }

    if (resource === "achievements" && req.user.role !== "student") {
      return res.status(403).json({
        success: false,
        message: "Only students can add achievements",
      });
    }

    const M = map[resource];

    if (!M) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }

    const body = { ...req.body };

    if (resource === "users") {
      if (!body.email || !/^[^\s@]+@kiot\.ac\.in$/i.test(body.email)) {
        return res.status(400).json({ success: false, message: "Use a valid @kiot.ac.in email" });
      }

      body.email = String(body.email).toLowerCase().trim();
      body.role = body.role || "student";
      body.accountType = body.role === "student" ? "student" : "staff";

      // Admin-created staff/faculty accounts do not need an admin-selected password.
      // Their first Staff Login opens the one-time password creation flow.
      const isFirstLoginStaff = ["faculty", "club_admin"].includes(body.role) && !body.password;
      if (isFirstLoginStaff) {
        const placeholder = crypto.randomBytes(32).toString("hex");
        body.password = await bcrypt.hash(placeholder, 12);
        body.mustSetPassword = true;
        body.passwordSetupTokenHash = "";
        body.passwordSetupExpires = null;
      } else {
        if (!body.password || String(body.password).length < 8) {
          return res.status(400).json({ success: false, message: body.role === "student" ? "Student password is required and must contain at least 8 characters" : "Password must contain at least 8 characters, or leave it blank for first-time staff password setup" });
        }
        body.password = await bcrypt.hash(String(body.password), 12);
        body.mustSetPassword = false;
        body.passwordSetupTokenHash = "";
        body.passwordSetupExpires = null;
      }
    }

    // FIX: ObjectId fields must not receive an empty string.
    if (resource === "clubs") {
      if (!body.incharge) {
        body.incharge = null;
      }

      if (!Array.isArray(body.clubAdmins)) {
        body.clubAdmins = [];
      }

      if (!Array.isArray(body.members)) {
        body.members = [];
      }

      if (!Array.isArray(body.objectives)) {
        body.objectives = [];
      }

      if (!Array.isArray(body.activities)) {
        body.activities = [];
      }
    }

    if (resource === "achievements") {
      body.user = req.user._id;
    }

    if (resource === "announcements") {
      body.createdBy = req.user._id;
    }

    if (resource === "discussions") {
      body.author = req.user._id;
    }

    if (resource === "events") {
      body.createdBy = req.user._id;

      if (req.user.role === "club_admin") {
        if (!body.club) {
          return res.status(400).json({
            success: false,
            message: "Select your club",
          });
        }

        const club = await Club.findById(body.club);

        if (!club || !canManageClub(req, club)) {
          return res.status(403).json({
            success: false,
            message: "You can only create events for your assigned club",
          });
        }
      }
    }

    const doc = await M.create(body);

    return res.status(201).json({
      success: true,
      message: "Created successfully",
      data: doc,
    });
  } catch (error) {
    console.error("Create error:", error);
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }
}

export async function update(req, res) {
  try {
    const resource = req.params.resource;
    const M = map[resource];

    if (!M) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }

    const doc = await M.findById(req.params.id);

    if (!doc) {
      return res.status(404).json({
        success: false,
        message: "Not found",
      });
    }

    if (resource === "users" && !isAdmin(req)) {
      return res.status(403).json({
        success: false,
        message: "Only super admin can manage users",
      });
    }

    if (resource === "clubs" && !canManageClub(req, doc)) {
      return res.status(403).json({
        success: false,
        message: "You can only update your assigned club",
      });
    }

    if (resource === "events" && !(await canManageEvent(req, doc))) {
      return res.status(403).json({
        success: false,
        message: "You can only update your club events",
      });
    }

    if (
      resource === "announcements" &&
      !isAdmin(req) &&
      doc.createdBy?.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only update your announcements",
      });
    }

    if (
      resource === "achievements" &&
      doc.user?.toString() !== req.user._id.toString() &&
      !isAdmin(req)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only update your achievement",
      });
    }

    if (
      resource === "discussions" &&
      doc.author?.toString() !== req.user._id.toString() &&
      !isAdmin(req)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only update your discussion",
      });
    }

    const updateData = { ...req.body };
    if (resource === "users") {
      if (updateData.email) {
        if (!/^[^\s@]+@kiot\.ac\.in$/i.test(String(updateData.email))) {
          return res.status(400).json({ success: false, message: "Use a valid @kiot.ac.in email" });
        }
        updateData.email = String(updateData.email).toLowerCase().trim();
      }
      if (updateData.role) {
        updateData.accountType = updateData.role === "student" ? "student" : "staff";
      }
      if (updateData.password !== undefined) {
        if (!String(updateData.password).trim()) delete updateData.password;
        else if (String(updateData.password).length < 8) {
          return res.status(400).json({ success: false, message: "Password must contain at least 8 characters" });
        } else {
          updateData.password = await bcrypt.hash(String(updateData.password), 12);
        }
      }
    }

    // FIX: Convert empty faculty selection to null before Mongoose validation.
    if (resource === "clubs") {
      if (!updateData.incharge) {
        updateData.incharge = null;
      }

      if (!Array.isArray(updateData.clubAdmins)) {
        updateData.clubAdmins = [];
      }

      if (!Array.isArray(updateData.members)) {
        updateData.members = [];
      }

      if (!Array.isArray(updateData.objectives)) {
        updateData.objectives = [];
      }

      if (!Array.isArray(updateData.activities)) {
        updateData.activities = [];
      }
    }

    Object.assign(doc, updateData);
    await doc.save();

    return res.json({
      success: true,
      message: "Updated successfully",
      data: doc,
    });
  } catch (error) {
    console.error("Update error:", error);
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }
}

export async function remove(req, res) {
  try {
    const resource = req.params.resource;
    const M = map[resource];

    if (!M) {
      return res.status(404).json({
        success: false,
        message: "Resource not found",
      });
    }

    const doc = await M.findById(req.params.id);

    if (!doc) {
      return res.status(404).json({
        success: false,
        message: "Not found",
      });
    }

    if (resource === "users" && !isAdmin(req)) {
      return res.status(403).json({
        success: false,
        message: "Only super admin can delete users",
      });
    }

    if (resource === "clubs" && !isAdmin(req)) {
      return res.status(403).json({
        success: false,
        message: "Only super admin can delete clubs",
      });
    }

    if (resource === "events" && !(await canManageEvent(req, doc))) {
      return res.status(403).json({
        success: false,
        message: "You can only delete your club events",
      });
    }

    if (
      resource === "announcements" &&
      !isAdmin(req) &&
      doc.createdBy?.toString() !== req.user._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only delete your announcements",
      });
    }

    if (
      resource === "achievements" &&
      doc.user?.toString() !== req.user._id.toString() &&
      !isAdmin(req)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only delete your achievement",
      });
    }

    if (
      resource === "discussions" &&
      doc.author?.toString() !== req.user._id.toString() &&
      !isAdmin(req)
    ) {
      return res.status(403).json({
        success: false,
        message: "You can only delete your discussion",
      });
    }

    await doc.deleteOne();

    return res.json({
      success: true,
      message: "Deleted successfully",
    });
  } catch (error) {
    console.error("Delete error:", error);
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }
}

const getStudentDetails = (req) => {
  const details = req.body?.details || {};
  return {
    user: req.user._id,
    fullName: String(details.fullName || req.user.name || "").trim(),
    email: String(details.email || req.user.email || "").trim().toLowerCase(),
    rollNo: String(details.rollNo || "").trim(),
    umis: String(details.umis || "").trim(),
    department: String(details.department || req.user.department || "").trim(),
    year: String(details.year || req.user.year || "").trim(),
    section: String(details.section || "").trim(),
    phone: String(details.phone || req.user.phone || "").trim(),
    registeredAt: new Date(),
  };
};

const validateStudentDetails = (details) => {
  const missing = [];
  if (!details.fullName) missing.push("Full name");
  if (!details.rollNo) missing.push("Roll number");
  if (!details.umis) missing.push("UMIS number");
  if (!details.department) missing.push("Department");
  if (!details.year) missing.push("Year");
  if (!details.phone) missing.push("Phone number");
  return missing;
};

export async function joinClub(req, res) {
  try {
    const club = await Club.findById(req.params.id);

    if (!club) {
      return res.status(404).json({ success: false, message: "Club not found" });
    }

    const userId = req.user._id.toString();
    const alreadyMember = club.members.some((x) => x.toString() === userId);

    if (alreadyMember) {
      return res.json({ success: true, message: "You are already a member", data: club });
    }

    const details = getStudentDetails(req);
    const missing = validateStudentDetails(details);

    if (missing.length) {
      return res.status(400).json({
        success: false,
        message: `Please provide: ${missing.join(", ")}`,
        missingFields: missing,
      });
    }

    club.members.push(req.user._id);
    club.memberDetails.push(details);
    await club.save();

    await Notification.create({
      user: req.user._id,
      title: `Joined ${club.name}`,
      message: `Your club registration for ${club.name} has been saved successfully.`,
      type: "club",
    });

    const saved = await Club.findById(club._id)
      .populate("incharge", "name email profileImage department year")
      .populate("clubAdmins", "name email profileImage department year")
      .populate("members", "name email profileImage department year");

    return res.json({
      success: true,
      message: `Successfully joined ${club.name}`,
      data: saved,
    });
  } catch (error) {
    console.error("Join club error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
}

export async function registerEvent(req, res) {
  try {
    const event = await Event.findById(req.params.id);

    if (!event) {
      return res.status(404).json({ success: false, message: "Event not found" });
    }

    if (event.maxParticipants && event.registrations.length >= event.maxParticipants) {
      return res.status(400).json({ success: false, message: "Event capacity is full" });
    }

    const userId = req.user._id.toString();
    const alreadyRegistered = event.registrations.some((x) => x.toString() === userId);

    if (alreadyRegistered) {
      return res.json({ success: true, message: "You are already registered for this event", data: event });
    }

    const details = getStudentDetails(req);
    const missing = validateStudentDetails(details);

    if (missing.length) {
      return res.status(400).json({
        success: false,
        message: `Please provide: ${missing.join(", ")}`,
        missingFields: missing,
      });
    }

    event.registrations.push(req.user._id);
    event.registrationDetails.push(details);
    await event.save();

    await Notification.create({
      user: req.user._id,
      title: `Registered for ${event.title}`,
      message: `Your student registration for ${event.title} has been saved successfully.`,
      type: "event",
    });

    const saved = await Event.findById(event._id)
      .populate("club", "name logo banner category")
      .populate("createdBy", "name profileImage role")
      .populate("facultyCoordinator", "name email profileImage department")
      .populate("registrations", "name profileImage")
        .populate("registrationDetails.user", "name email profileImage department year");

    return res.json({
      success: true,
      message: `Successfully registered for ${event.title}`,
      data: saved,
    });
  } catch (error) {
    console.error("Register event error:", error);
    return res.status(400).json({ success: false, message: error.message });
  }
}

export async function addComment(req, res) {
  try {
    const discussion = await Discussion.findById(req.params.id);

    if (!discussion) {
      return res.status(404).json({
        success: false,
        message: "Discussion not found",
      });
    }

    if (!req.body.content?.trim()) {
      return res.status(400).json({
        success: false,
        message: "Comment is required",
      });
    }

    discussion.comments.push({
      user: req.user._id,
      content: req.body.content.trim(),
    });

    await discussion.save();

    const data = await Discussion.findById(discussion._id)
      .populate("author", "name profileImage")
      .populate("comments.user", "name profileImage");

    return res.json({
      success: true,
      message: "Comment added",
      data,
    });
  } catch (error) {
    console.error("Add comment error:", error);
    return res.status(400).json({
      success: false,
      message: error.message,
    });
  }
}

export async function stats(req, res) {
  try {
    const [
      users,
      clubs,
      events,
      announcements,
      achievements,
      discussions,
    ] = await Promise.all([
      User.countDocuments(),
      Club.countDocuments(),
      Event.countDocuments(),
      Announcement.countDocuments(),
      Achievement.countDocuments(),
      Discussion.countDocuments(),
    ]);

    return res.json({
      success: true,
      data: {
        users,
        clubs,
        events,
        announcements,
        achievements,
        discussions,
      },
    });
  } catch (error) {
    console.error("Stats error:", error);
    return res.status(500).json({
      success: false,
      message: error.message,
    });
  }
}
