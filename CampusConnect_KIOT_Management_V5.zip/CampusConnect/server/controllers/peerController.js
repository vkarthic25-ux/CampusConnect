import PeerGroup from "../models/PeerGroup.js";
import PeerMessage from "../models/PeerMessage.js";
import User from "../models/User.js";

const canUse = (user) => !!user && user.isActive;

export async function listGroups(req, res) {
  try {
    const filter = {};
    if (req.query.department) filter.department = req.query.department;
    let groups = await PeerGroup.find(filter)
      .populate("members", "name role department year section profileImage")
      .sort({ department: 1, name: 1 });

    // If a newly created department has no group yet, create one automatically.
    if (req.user?.department && !req.query.department) {
      const exists = groups.some((g) => g.department === req.user.department);
      if (!exists) {
        const group = await PeerGroup.create({
          name: `${req.user.department} Seniors & Juniors`,
          department: req.user.department,
          description: `WhatsApp-style peer group for ${req.user.department} students to ask questions, share notes and connect across years.`,
          members: req.user.role === "student" ? [req.user._id] : [],
        });
        groups.push(await PeerGroup.findById(group._id).populate("members", "name role department year section profileImage"));
      }
    }
    res.json({ data: groups });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function joinGroup(req, res) {
  try {
    if (!canUse(req.user)) return res.status(403).json({ message: "Account is inactive" });
    const group = await PeerGroup.findById(req.params.id);
    if (!group) return res.status(404).json({ message: "Peer group not found" });
    if (req.user.role !== "student") return res.status(403).json({ message: "Senior-Junior groups are for students" });
    if (req.user.department && group.department !== req.user.department) return res.status(403).json({ message: "Join your department peer group" });
    if (!group.members.some((id) => id.toString() === req.user._id.toString())) group.members.push(req.user._id);
    await group.save();
    const data = await PeerGroup.findById(group._id).populate("members", "name role department year section profileImage");
    res.json({ data });
  } catch (e) { res.status(400).json({ message: e.message }); }
}

async function getGroup(req, user) {
  const group = await PeerGroup.findById(req.params.id);
  if (!group) return { error: [404, "Peer group not found"] };
  const member = group.members.some((id) => id.toString() === user._id.toString());
  if (!member && user.role !== "super_admin" && user.role !== "faculty") return { error: [403, "Join this group to access its chat"] };
  return { group };
}

export async function messages(req, res) {
  try {
    const result = await getGroup(req, req.user);
    if (result.error) return res.status(result.error[0]).json({ message: result.error[1] });
    const data = await PeerMessage.find({ group: result.group._id })
      .populate("sender", "name role department year section profileImage")
      .sort({ createdAt: 1 }).limit(300);
    res.json({ data });
  } catch (e) { res.status(500).json({ message: e.message }); }
}

export async function sendMessage(req, res) {
  try {
    const result = await getGroup(req, req.user);
    if (result.error) return res.status(result.error[0]).json({ message: result.error[1] });
    if (req.user.role !== "student" && req.user.role !== "faculty" && req.user.role !== "club_admin" && req.user.role !== "super_admin") return res.status(403).json({ message: "Chat is unavailable" });
    const message = String(req.body.message || "").trim();
    if (!message) return res.status(400).json({ message: "Message is required" });
    const doc = await PeerMessage.create({ group: result.group._id, sender: req.user._id, message });
    const data = await doc.populate("sender", "name role department year section profileImage");
    res.status(201).json({ data });
  } catch (e) { res.status(400).json({ message: e.message }); }
}

export async function members(req, res) {
  try {
    const result = await getGroup(req, req.user);
    if (result.error) return res.status(result.error[0]).json({ message: result.error[1] });
    const data = await User.find({ _id: { $in: result.group.members }, isActive: true })
      .select("name role department year section subjects skills profileImage bio")
      .sort({ year: 1, name: 1 });
    res.json({ data });
  } catch (e) { res.status(500).json({ message: e.message }); }
}
