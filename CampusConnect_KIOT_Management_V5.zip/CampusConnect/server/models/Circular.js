import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    content: { type: String, required: true, trim: true },
    audience: { type: String, enum: ["all", "students", "staff"], default: "all" },
    department: { type: String, default: "All Departments", trim: true },
    attachmentName: { type: String, default: "" },
    attachmentType: { type: String, default: "" },
    attachmentData: { type: String, default: "" },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true }
);

export default mongoose.model("Circular", schema);
