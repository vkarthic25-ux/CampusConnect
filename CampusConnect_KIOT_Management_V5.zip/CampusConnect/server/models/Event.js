import mongoose from "mongoose";

const registrationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, lowercase: true, trim: true },
    rollNo: { type: String, default: "", trim: true },
    umis: { type: String, default: "", trim: true },
    department: { type: String, default: "", trim: true },
    year: { type: String, default: "", trim: true },
    section: { type: String, default: "", trim: true },
    phone: { type: String, default: "", trim: true },
    registeredAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const schema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "" },
    category: { type: String, default: "General" },
    banner: { type: String, default: "" },
    date: { type: Date, required: true },
    startTime: { type: String, default: "" },
    endTime: { type: String, default: "" },
    venue: { type: String, default: "" },
    club: { type: mongoose.Schema.Types.ObjectId, ref: "Club" },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    facultyCoordinator: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    maxParticipants: { type: Number, default: 0 },
    registrations: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    registrationDetails: { type: [registrationSchema], default: [] },
  },
  { timestamps: true }
);

export default mongoose.model("Event", schema);
