import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    title: { type: String, required: true, trim: true },
    description: { type: String, default: "", trim: true },
    subject: { type: String, default: "", trim: true },
    department: { type: String, default: "", trim: true },
    category: { type: String, default: "Notes", trim: true },
    fileName: { type: String, required: true },
    mimeType: { type: String, required: true },
    fileData: { type: String, required: true },
    fileSize: { type: Number, default: 0 },
    uploadedBy: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  },
  { timestamps: true }
);

export default mongoose.model("Resource", schema);
