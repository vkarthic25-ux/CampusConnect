import mongoose from "mongoose";

const schema = new mongoose.Schema(
  {
    group: { type: mongoose.Schema.Types.ObjectId, ref: "PeerGroup", required: true, index: true },
    sender: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    message: { type: String, required: true, trim: true, maxlength: 3000 },
  },
  { timestamps: true }
);

export default mongoose.model("PeerMessage", schema);
