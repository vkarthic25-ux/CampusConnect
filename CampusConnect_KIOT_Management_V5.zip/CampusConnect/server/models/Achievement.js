import mongoose from 'mongoose';
const schema=new mongoose.Schema({user:{type:mongoose.Schema.Types.ObjectId,ref:'User',required:true},title:{type:String,required:true},description:{type:String,default:''},category:{type:String,default:'Other'},date:{type:Date,default:Date.now},image:{type:String,default:''}},{timestamps:true});
export default mongoose.model('Achievement',schema);
