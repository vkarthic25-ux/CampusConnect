import mongoose from "mongoose";

const registrationSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
    fullName: { type: String, required: true, trim: true },
    email: { type: String, required: true, lowercase: true, trim: true },
    rollNo: { type: String, default: "", trim: true },
    umis: { type: String, default: "", trim: true },
    department: { type: String, default: "", trim: true },
    year: { type: String, default: "", trim: true },
    section: { type: String, default: "", trim: true },
    phone: { type: String, default: "", trim: true },
    registeredAt: { type: Date, default: Date.now },
  },
  { _id: false }
);

const clubSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    code: { type: String, default: "", trim: true },
    description: { type: String, default: "", trim: true },
    category: { type: String, default: "General", trim: true },
    logo: { type: String, default: "" },
    coverImage: { type: String, default: "" },
    banner: { type: String, default: "" },
    objectives: { type: [String], default: [] },
    activities: { type: [String], default: [] },
    incharge: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null },
    clubAdmins: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    members: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
    memberDetails: { type: [registrationSchema], default: [] },
  },
  { timestamps: true }
);

export default mongoose.model("Club", clubSchema);
