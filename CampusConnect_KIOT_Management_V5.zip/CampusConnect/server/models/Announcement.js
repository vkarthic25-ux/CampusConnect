import mongoose from 'mongoose';
const schema=new mongoose.Schema({title:{type:String,required:true},content:{type:String,required:true},createdBy:{type:mongoose.Schema.Types.ObjectId,ref:'User'},priority:{type:String,enum:['low','normal','high'],default:'normal'}},{timestamps:true});
export default mongoose.model('Announcement',schema);
