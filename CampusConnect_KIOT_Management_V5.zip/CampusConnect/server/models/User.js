import mongoose from 'mongoose';

const userSchema = new mongoose.Schema({
  name:{type:String,required:true,trim:true},
  email:{type:String,required:true,unique:true,lowercase:true,trim:true},
  password:{type:String,required:true,minlength:8},
  role:{type:String,enum:['student','faculty','club_admin','super_admin'],default:'student'},
  accountType:{type:String,enum:['student','staff'],default:'student'},
  profileImage:{type:String,default:''},
  phone:{type:String,default:''},
  department:{type:String,default:''},
  year:{type:String,default:''},
  section:{type:String,default:''},
  rollNo:{type:String,default:''},
  umis:{type:String,default:''},
  batch:{type:String,default:''},
  subjects:{type:[String],default:[]},
  skills:{type:[String],default:[]},
  bio:{type:String,default:''},
  designation:{type:String,default:''},
  qualification:{type:String,default:''},
  employeeId:{type:String,default:''},
  isActive:{type:Boolean,default:true},
  isVerified:{type:Boolean,default:true},
  mustSetPassword:{type:Boolean,default:false},
  passwordSetupTokenHash:{type:String,default:''},
  passwordSetupExpires:{type:Date,default:null},
  lastLoginAt:{type:Date,default:null},
  loginCount:{type:Number,default:0}
},{timestamps:true});
export default mongoose.model('User',userSchema);
