import 'dotenv/config';import express from 'express';import cors from 'cors';import connectDB from './config/db.js';import auth from './routes/auth.js';import resources from './routes/resources.js';import profile from './routes/profile.js';import notifications from './routes/notifications.js';import extras from './routes/extras.js';
import circular from './routes/circular.js';
import staff from './routes/staff.js';import peer from './routes/peer.js';
const app=express();app.use(cors({origin:process.env.CLIENT_URL||'http://localhost:5173'}));app.use(express.json({limit:'12mb'}));app.get('/',(req,res)=>res.json({message:'CampusConnect API is running'}));app.use('/api/auth',auth);app.use('/api/profile',profile);app.use('/api/notifications',notifications);app.use('/api',extras);
app.use('/api/circulars', circular);
app.use('/api/staff', staff);app.use('/api',peer);app.use('/api',resources);app.use((err,req,res,next)=>{console.error(err);res.status(500).json({message:'Server error'});});const port=process.env.PORT||5000;connectDB().then(()=>app.listen(port,()=>console.log(`Server running on http://localhost:${port}`))).catch(e=>{console.error(e);process.exit(1)});
