import 'dotenv/config';
import bcrypt from 'bcryptjs';
import connectDB from './config/db.js';
import User from './models/User.js';
import Club from './models/Club.js';
import Event from './models/Event.js';
import Announcement from './models/Announcement.js';
import Achievement from './models/Achievement.js';
import Discussion from './models/Discussion.js';
import Notification from './models/Notification.js';
import PeerGroup from './models/PeerGroup.js';
import Circular from './models/Circular.js';

await connectDB();

const accounts = [
  ['Admin','admin@kiot.ac.in','Admin@123','super_admin'],
  ['Faculty','faculty@kiot.ac.in','Faculty@123','faculty'],
  ['Club Admin','clubadmin@kiot.ac.in','ClubAdmin@123','club_admin'],
  ['Student','student@kiot.ac.in','Student@123','student']
];

const users = {};
for (const [name,email,pwd,role] of accounts) {
  const hash = await bcrypt.hash(pwd,12);
  const common = {
    name,email,password:hash,role,accountType:role === 'student' ? 'student' : 'staff',mustSetPassword:false,passwordSetupTokenHash:'',passwordSetupExpires:null,isVerified:true,isActive:true,
    department: role === 'faculty' || role === 'club_admin' ? 'CSE' : 'Computer Science and Engineering',
    year: role === 'student' ? '3rd Year' : '',
    section: role === 'student' ? 'A' : '',
    phone: role === 'student' ? '9876543210' : '04272433900',
    subjects: role === 'student' ? ['Data Structures','Database Management','Web Development'] : ['Programming','Software Engineering'],
    skills: role === 'student' ? ['React','Node.js','MongoDB','JavaScript'] : ['Teaching','Mentoring','Research'],
    bio: role === 'faculty' ? 'Faculty member and academic mentor at KIOT.' : role === 'club_admin' ? 'Club coordinator for student activities.' : '',
    designation: role === 'faculty' ? 'Assistant Professor' : role === 'club_admin' ? 'Club Coordinator' : '',
    qualification: role === 'faculty' ? 'M.E., Ph.D.' : '',
    employeeId: role === 'faculty' || role === 'club_admin' ? `KIOT-${role.toUpperCase()}` : '',
  };
  if(role === 'student') Object.assign(common,{rollNo:'23CSE101',umis:'UMIS2026101',batch:'2023-2027'});
  users[role] = await User.findOneAndUpdate({email},common,{upsert:true,new:true,setDefaultsOnInsert:true});
}

const studentDetails = {
  user: users.student._id,
  fullName: users.student.name,
  email: users.student.email,
  rollNo: users.student.rollNo,
  umis: users.student.umis,
  department: users.student.department,
  year: users.student.year,
  section: users.student.section,
  phone: users.student.phone,
  registeredAt: new Date()
};

const coding = await Club.findOneAndUpdate({name:'Coding Club'}, {
  name:'Coding Club',code:'CC',description:'Programming, projects, competitive coding and technical activities for KIOT students.',category:'Technical',banner:'/assets/club-coding.svg',logo:'/assets/college-logo.svg',incharge:users.faculty,clubAdmins:[users.club_admin],members:[users.club_admin,users.student],memberDetails:[studentDetails],objectives:['Build technical skills','Run coding workshops','Encourage project development'],activities:['CodeSprint','Git workshops','Project showcases']
},{upsert:true,new:true,setDefaultsOnInsert:true});

const cultural = await Club.findOneAndUpdate({name:'Cultural Club'}, {
  name:'Cultural Club',code:'CUL',description:'A community for music, dance, art, literature and cultural celebrations.',category:'Cultural',banner:'/assets/club-cultural.svg',logo:'/assets/college-logo.svg',incharge:users.faculty,members:[users.student],memberDetails:[studentDetails],objectives:['Celebrate campus culture','Promote student talent'],activities:['Cultural Fest','Music events','Art showcases']
},{upsert:true,new:true,setDefaultsOnInsert:true});

const sports = await Club.findOneAndUpdate({name:'Sports Club'}, {
  name:'Sports Club',code:'SP',description:'Sports, fitness and inter-department competitions across campus.',category:'Sports',banner:'/assets/club-sports.svg',logo:'/assets/college-logo.svg',incharge:users.faculty,members:[users.student],memberDetails:[studentDetails],objectives:['Promote fitness','Conduct sports meets'],activities:['Sports Day','Inter-department tournaments']
},{upsert:true,new:true,setDefaultsOnInsert:true});

const eventSeed = [
 ['CampusConnect Innovation Day','Official innovation and technology showcase for KIOT students.',7,'Main Auditorium',coding,'/assets/event-innovation.svg','Technical'],
 ['CodeSprint 2026','A hands-on coding challenge for students.',14,'Innovation Lab',coding,'/assets/event-innovation.svg','Hackathon'],
 ['Cultural Fest 2026','Music, dance and cultural performances.',21,'Open Air Auditorium',cultural,'/assets/event-culture.svg','Cultural'],
 ['KIOT Sports Day','Inter-department sports and team activities.',28,'Sports Ground',sports,'/assets/event-sports.svg','Sports']
];
for(const [title,description,days,venue,club,banner,category] of eventSeed){
  await Event.findOneAndUpdate({title},{title,description,category,banner,date:new Date(Date.now()+days*86400000),venue,club:club._id,createdBy:users.super_admin,facultyCoordinator:users.faculty,maxParticipants:200,registrations:[users.student],registrationDetails:[studentDetails]},{upsert:true,new:true,setDefaultsOnInsert:true});
}

const anns=[['Welcome to CampusConnect','Welcome to the new KIOT College Community Portal. Complete your profile and explore clubs and events.','high'],['Inter-Department Event Registration Open','Registrations are now open for upcoming student activities.','normal'],['Profile Update Reminder','Add your department, year and achievements to complete your campus profile.','low']];
for(const [title,content,priority] of anns)await Announcement.findOneAndUpdate({title},{title,content,createdBy:users.super_admin,priority},{upsert:true,new:true,setDefaultsOnInsert:true});
await Achievement.findOneAndUpdate({user:users.student,title:'Hackathon Participant – 2026'},{user:users.student,title:'Hackathon Participant – 2026',description:'Participated in a college-level innovation and coding hackathon.',category:'Hackathon',date:new Date()},{upsert:true,new:true,setDefaultsOnInsert:true});
await Achievement.findOneAndUpdate({user:users.student,title:'Academic Excellence'},{user:users.student,title:'Academic Excellence',description:'Recognized for consistent academic performance and technical learning.',category:'Academic',date:new Date()},{upsert:true,new:true,setDefaultsOnInsert:true});
await Discussion.findOneAndUpdate({title:'Ideas for upcoming technical events'},{title:'Ideas for upcoming technical events',content:'What workshops or coding activities would you like the Coding Club to conduct this semester?',author:users.student,comments:[{user:users.club_admin,content:'We are planning a CodeSprint and Git workshop soon.'}]},{upsert:true,new:true,setDefaultsOnInsert:true});
await Notification.findOneAndUpdate({user:users.student,title:'Welcome to CampusConnect'},{user:users.student,title:'Welcome to CampusConnect',message:'Complete your profile and explore KIOT clubs and events.',type:'welcome',isRead:false},{upsert:true,new:true,setDefaultsOnInsert:true});

const circulars=[['Academic Calendar & Important Instructions','Students are requested to check the academic calendar, complete required registrations and follow department instructions.','students','All Departments'],['Faculty Club Registration Review','Faculty in-charges can review club registered student records from the Club Registered Members workspace.','staff','All Departments']];
for(const [title,content,audience,department] of circulars) await Circular.findOneAndUpdate({title},{title,content,audience,department,createdBy:users.super_admin},{upsert:true,new:true,setDefaultsOnInsert:true});

const peerDepartments = ['Computer Science and Engineering','CSE','IT','ECE','EEE','MECH','CIVIL','AI&DS','CSBS'];
for (const department of peerDepartments) {
  const members = await User.find({ role: 'student', department });
  await PeerGroup.findOneAndUpdate(
    { department },
    { name: `${department} Seniors & Juniors`, department, description: `WhatsApp-style peer group for ${department} students to connect across years, ask questions and share study resources.`, members: members.map(m => m._id) },
    { upsert: true, new: true, setDefaultsOnInsert: true }
  );
}

console.log('Seed complete.');
console.log('Admin: admin@kiot.ac.in / Admin@123');
console.log('Faculty: faculty@kiot.ac.in / Faculty@123');
console.log('Club Admin: clubadmin@kiot.ac.in / ClubAdmin@123');
console.log('Student: student@kiot.ac.in / Student@123');
process.exit(0);
