# CampusConnect – KIOT College Community Portal

## UI + MongoDB upgraded version
This version follows the requested KIOT-style dashboard layout with a college banner, sidebar navigation, dashboard cards, detailed club pages, profile editing, achievements, events, announcements, discussions, notifications and admin user management.

## Run Backend
```cmd
cd server
npm install
npm run seed
npm run dev
```
Backend: http://localhost:5000

## Run Frontend
Open a second terminal:
```cmd
cd client
npm install
npm run dev
```
Frontend: http://localhost:5173

## MongoDB
The backend is configured for local MongoDB:
```text
mongodb://127.0.0.1:27017/campusconnect
```
Start the MongoDB service before running the seed/server.
Open MongoDB Compass and connect to `mongodb://127.0.0.1:27017` to view the `campusconnect` database.

## Demo accounts
- Admin: admin@kiot.ac.in / Admin@123
- Faculty: faculty@kiot.ac.in / Faculty@123
- Club Admin: clubadmin@kiot.ac.in / ClubAdmin@123
- Student: student@kiot.ac.in / Student@123

## Main features
- @kiot.ac.in registration/login restriction
- JWT authentication
- MongoDB persistence with Mongoose
- Student profile editing
- Achievement add/delete
- Club creation, club details and join action
- Faculty in-charge and club member details
- Event creation and registration
- Announcement creation and display
- Discussions with comments
- Notifications and mark-as-read
- Super admin user management
- Responsive KIOT-inspired UI
