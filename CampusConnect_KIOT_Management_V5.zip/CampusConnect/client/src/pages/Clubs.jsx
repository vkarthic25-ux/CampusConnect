import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { FaUsers, FaEye, FaEdit, FaTrash, FaUpload, FaEnvelope, FaUserTie, FaComments } from "react-icons/fa";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import PageHeader from "../components/common/PageHeader";
import Modal from "../components/common/Modal";
import StudentRegistrationModal from "../components/common/StudentRegistrationModal";

const empty = { name: "", description: "", category: "Technical", incharge: "", clubAdmins: [], banner: "" };

export default function Clubs() {
  const { user } = useAuth();
  const nav = useNavigate();
  const [data, setData] = useState([]);
  const [people, setPeople] = useState([]);
  const [open, setOpen] = useState(false);
  const [detail, setDetail] = useState(null);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [registerClub, setRegisterClub] = useState(null);
  const [saving, setSaving] = useState(false);
  const [joining, setJoining] = useState(false);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const r = await API.get("/clubs");
      setData(r.data?.data || []);
      setError("");
    } catch (e) {
      setError(e.response?.data?.message || "Unable to load clubs.");
    }
  };

  const loadPeople = async () => {
    try {
      const r = await API.get("/users");
      setPeople(r.data?.data || []);
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => { load(); loadPeople(); }, []);

  const startCreate = () => {
    setEditing(null);
    setForm(empty);
    setOpen(true);
  };

  const startEdit = (club) => {
    setEditing(club);
    setForm({
      name: club.name || "",
      description: club.description || "",
      category: club.category || "Technical",
      incharge: club.incharge?._id || club.incharge || "",
      clubAdmins: (club.clubAdmins || []).map((x) => x._id || x),
      banner: club.banner || "",
    });
    setOpen(true);
  };

  const save = async (event) => {
    event.preventDefault();
    try {
      setSaving(true);
      const payload = {
        name: form.name.trim(),
        description: form.description.trim(),
        category: form.category,
        incharge: form.incharge || null,
        clubAdmins: (form.clubAdmins || []).filter(Boolean),
        banner: form.banner || "",
      };
      if (editing) await API.put(`/clubs/${editing._id}`, payload);
      else await API.post("/clubs", payload);
      setOpen(false);
      await load();
      alert(editing ? "Club updated successfully." : "Club created successfully.");
    } catch (e) {
      alert(e.response?.data?.message || "Unable to save club.");
    } finally { setSaving(false); }
  };

  const remove = async (id) => {
    if (!window.confirm("Delete this club?")) return;
    try { await API.delete(`/clubs/${id}`); await load(); }
    catch (e) { alert(e.response?.data?.message || "Unable to delete club."); }
  };

  const submitJoin = async (details) => {
    if (!registerClub) return;
    try {
      setJoining(true);
      const r = await API.post(`/clubs/${registerClub._id}/join`, { details });
      setRegisterClub(null);
      await load();
      alert(r.data?.message || "Club registration saved successfully.");
    } catch (e) {
      alert(e.response?.data?.message || "Unable to register for club.");
    } finally { setJoining(false); }
  };

  const view = async (id) => {
    try {
      const r = await API.get(`/clubs/${id}`);
      setDetail(r.data?.data);
    } catch (e) { alert(e.response?.data?.message || "Unable to load club details."); }
  };

  const isManager = (club) => {
    if (user?.role === "super_admin") return true;
    if (user?.role !== "club_admin") return false;
    const id = user?._id?.toString();
    return (club.clubAdmins || []).some((x) => (x._id || x)?.toString() === id) || (club.incharge?._id || club.incharge)?.toString() === id;
  };

  const upload = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => setForm((x) => ({ ...x, banner: reader.result }));
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-6">
      <PageHeader title="Explore Clubs" description="Join KIOT communities, connect with students and participate in technical, cultural, sports and social activities." buttonText={user?.role === "super_admin" ? "Create Club" : undefined} onClick={startCreate} />
      {(user?.role === "faculty" || user?.role === "super_admin") && <button onClick={() => nav("/club-members")} className="rounded-xl bg-blue-50 px-4 py-3 text-sm font-black text-blue-700 hover:bg-blue-100">View Club Registered Members</button>}
      {error && <div className="rounded-2xl border border-red-200 bg-red-50 p-4 font-semibold text-red-700">{error}</div>}

      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {data.map((club) => (
          <article key={club._id} className="group overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition duration-300 hover:-translate-y-1 hover:shadow-2xl">
            <div className="relative h-48 overflow-hidden bg-gradient-to-br from-blue-950 via-blue-700 to-cyan-500">
              {club.banner && <img src={club.banner} alt={club.name} className="h-full w-full object-cover transition duration-500 group-hover:scale-105" />}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-950/10 to-transparent" />
              <div className="absolute left-5 right-5 bottom-5 text-white">
                <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-bold backdrop-blur">{club.category}</span>
                <h2 className="mt-2 text-2xl font-black">{club.name}</h2>
              </div>
            </div>
            <div className="p-5">
              <p className="line-clamp-2 min-h-[48px] text-sm leading-6 text-slate-500">{club.description || "KIOT student community."}</p>
              <div className="mt-4 flex items-center gap-3 rounded-2xl bg-slate-50 p-3">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center overflow-hidden rounded-full bg-blue-100 font-black text-blue-700">
                  {club.incharge?.profileImage ? <img src={club.incharge.profileImage} alt="" className="h-full w-full object-cover" /> : (club.incharge?.name || "F").charAt(0).toUpperCase()}
                </div>
                <div className="min-w-0">
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400">Faculty In-Charge</p>
                  <p className="truncate font-extrabold text-slate-800">{club.incharge?.name || "Not assigned"}</p>
                  <p className="truncate text-xs text-slate-500">{club.incharge?.department || "KIOT Faculty"}</p>
                </div>
              </div>
              <div className="mt-4 grid grid-cols-2 gap-2">
                <button onClick={() => view(club._id)} className="rounded-xl border border-slate-200 py-2.5 text-sm font-extrabold hover:bg-slate-50"><FaEye className="mr-1 inline" />Details</button>
                <button onClick={() => setRegisterClub(club)} className="rounded-xl bg-blue-600 py-2.5 text-sm font-extrabold text-white hover:bg-blue-700">Register</button>
              </div>
              {isManager(club) && <div className="mt-2 grid grid-cols-2 gap-2"><button onClick={() => startEdit(club)} className="rounded-xl bg-amber-50 py-2.5 text-sm font-extrabold text-amber-700"><FaEdit className="mr-1 inline" />Edit</button>{user?.role === "super_admin" && <button onClick={() => remove(club._id)} className="rounded-xl bg-red-50 py-2.5 text-sm font-extrabold text-red-600"><FaTrash className="mr-1 inline" />Delete</button>}</div>}
            </div>
          </article>
        ))}
        {!data.length && <div className="md:col-span-2 xl:col-span-3 rounded-3xl border-2 border-dashed border-slate-200 bg-white p-14 text-center"><FaUsers className="mx-auto text-5xl text-blue-200" /><h3 className="mt-4 text-xl font-black">No clubs available</h3><p className="mt-1 text-slate-500">Clubs created by the Super Admin will appear here.</p></div>}
      </div>

      <Modal open={open} onClose={() => !saving && setOpen(false)} title={editing ? "Update Club" : "Create New Club"} wide>
        <form onSubmit={save} className="space-y-4">
          <Field label="Club Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} required />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Category" select value={form.category} onChange={(v) => setForm({ ...form, category: v })} options={["Technical", "Cultural", "Sports", "Literary", "Entrepreneurship", "Social Service", "Arts", "Other"]} />
            <Field label="Faculty In-Charge" select value={form.incharge} onChange={(v) => setForm({ ...form, incharge: v })} options={[{ value: "", label: "No faculty assigned" }, ...people.filter((p) => p.role === "faculty").map((p) => ({ value: p._id, label: `${p.name} • ${p.department || "Faculty"}` }))]} />
          </div>
          <Field label="Description" textarea value={form.description} onChange={(v) => setForm({ ...form, description: v })} required />
          <Field label="Club Admin" select value={form.clubAdmins?.[0] || ""} onChange={(v) => setForm({ ...form, clubAdmins: v ? [v] : [] })} options={[{ value: "", label: "No club admin assigned" }, ...people.filter((p) => p.role === "club_admin").map((p) => ({ value: p._id, label: `${p.name} • ${p.email}` }))]} />
          <label className="block"><span className="mb-2 block text-sm font-black">Club Banner</span><div className="rounded-2xl border-2 border-dashed border-slate-200 p-3">{form.banner && <img src={form.banner} alt="Preview" className="mb-3 h-44 w-full rounded-xl object-cover" />}<label className="flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-slate-50 px-4 py-3 font-bold text-slate-600 hover:bg-blue-50 hover:text-blue-700"><FaUpload /> Choose Banner Image<input type="file" accept="image/*" className="hidden" onChange={upload} /></label></div></label>
          <button disabled={saving} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-black text-white disabled:opacity-60">{saving ? "Saving..." : editing ? "Save Club Changes" : "Create Club"}</button>
        </form>
      </Modal>

      <Modal open={!!detail} onClose={() => setDetail(null)} title={detail?.name || "Club Details"} wide>
        {detail && <div className="space-y-6"><div className="relative h-56 overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950 to-cyan-500">{detail.banner && <img src={detail.banner} alt={detail.name} className="h-full w-full object-cover" />}<div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent" /><div className="absolute bottom-5 left-5 text-white"><p className="text-xs font-bold uppercase tracking-widest">{detail.category}</p><h2 className="text-3xl font-black">{detail.name}</h2></div></div><p className="leading-7 text-slate-600">{detail.description}</p><div className="grid gap-4 md:grid-cols-3"><Info title="Faculty In-Charge"><p className="font-extrabold">{detail.incharge?.name || "Not assigned"}</p><p className="text-xs text-slate-500">{detail.incharge?.email || ""}</p></Info><Info title="Members"><p className="text-3xl font-black text-blue-600">{detail.members?.length || 0}</p><p className="text-sm text-slate-500">Registered members</p></Info><Info title="Registration Records"><p className="text-3xl font-black text-cyan-600">{detail.memberDetails?.length || detail.members?.length || 0}</p><p className="text-sm text-slate-500">Student detail records</p></Info></div><Info title="Recent Registered Students"><div className="space-y-2">{(detail.memberDetails || []).slice(-8).reverse().map((m, i) => <div key={`${m.user}-${i}`} className="flex items-center justify-between rounded-xl bg-slate-50 p-3"><div><p className="font-bold">{m.fullName}</p><p className="text-xs text-slate-500">{m.rollNo} • {m.department} • {m.year}</p></div><span className="text-xs font-bold text-blue-600">{m.umis}</span></div>)}{!detail.memberDetails?.length && <p className="text-sm text-slate-500">No detailed registration records yet.</p>}</div></Info></div>}
      </Modal>

      <StudentRegistrationModal open={!!registerClub} onClose={() => setRegisterClub(null)} title={`Register for ${registerClub?.name || "Club"}`} subtitle="Enter your college student details. These details will be stored inside this club's member registration records." onSubmit={submitJoin} loading={joining} />
    </div>
  );
}

function Info({ title, children }) { return <div className="rounded-2xl border border-slate-200 bg-slate-50/70 p-4"><p className="mb-3 text-xs font-black uppercase tracking-widest text-slate-400">{title}</p>{children}</div>; }
function Field({ label, value, onChange, textarea, select, options = [], required }) { return <label className="block"><span className="mb-1.5 block text-sm font-black text-slate-700">{label}</span>{select ? <select required={required} value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5">{options.map((o) => typeof o === "string" ? <option key={o}>{o}</option> : <option key={o.value} value={o.value}>{o.label}</option>)}</select> : textarea ? <textarea required={required} rows="4" value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5" /> : <input required={required} value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5" />}</label>; }
