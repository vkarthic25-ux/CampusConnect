import React, { useEffect, useMemo, useState } from "react";
import { FaEdit, FaPlus, FaSearch, FaTrash, FaUserShield, FaUsers, FaSave, FaTimes, FaChalkboardTeacher } from "react-icons/fa";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import PageHeader from "../components/common/PageHeader";
import Modal from "../components/common/Modal";
import Avatar from "../components/common/Avatar";

const empty = {
  name:"", email:"", password:"", role:"student", phone:"", department:"", year:"", section:"",
  rollNo:"", umis:"", batch:"", subjects:"", skills:"", designation:"", qualification:"", employeeId:"", bio:"", isActive:true
};

export default function Users(){
  const {user}=useAuth();
  const [data,setData]=useState([]),[tab,setTab]=useState("students"),[q,setQ]=useState(""),[open,setOpen]=useState(false),[editing,setEditing]=useState(null),[form,setForm]=useState(empty),[loading,setLoading]=useState(true),[saving,setSaving]=useState(false),[error,setError]=useState("");

  const load=async()=>{
    try{
      setLoading(true);
      const r=await API.get("/users");
      setData(r.data?.data||[]);
      setError("");
    }catch(e){setError(e.response?.data?.message||"Unable to load users.")}
    finally{setLoading(false)}
  };

  useEffect(()=>{if(user?.role==="super_admin")load()},[user?.role]);

  const students=data.filter(u=>u.role==="student");
  const staff=data.filter(u=>["faculty","club_admin"].includes(u.role));
  const source=tab==="students"?students:tab==="staff"?staff:data.filter(u=>u.role==="super_admin");
  const filtered=useMemo(()=>source.filter(u=>`${u.name} ${u.email} ${u.department} ${u.rollNo} ${u.umis} ${u.employeeId} ${u.designation} ${u.role}`.toLowerCase().includes(q.toLowerCase())),[source,q]);

  if(user?.role!=="super_admin")return <div className="rounded-3xl bg-white p-10 text-center font-bold text-slate-600">Only Super Admin can manage student and staff records.</div>;

  const openCreate=(role="student")=>{
    setEditing(null);
    setForm({...empty,role,designation:role==="faculty"?"Assistant Professor":""});
    setOpen(true);
    setError("");
  };

  const openEdit=u=>{
    setEditing(u);
    setForm({...empty,...u,password:"",subjects:Array.isArray(u.subjects)?u.subjects.join(", "):u.subjects||"",skills:Array.isArray(u.skills)?u.skills.join(", "):u.skills||""});
    setOpen(true);
    setError("");
  };

  const save=async e=>{
    e.preventDefault();
    setSaving(true);setError("");
    try{
      const payload={...form,subjects:String(form.subjects||"").split(",").map(x=>x.trim()).filter(Boolean),skills:String(form.skills||"").split(",").map(x=>x.trim()).filter(Boolean)};
      if(!payload.password)delete payload.password;
      if(editing)await API.put(`/users/${editing._id}`,payload);
      else await API.post("/users",payload);
      setOpen(false);
      await load();
      alert(editing?"User details updated successfully.":payload.role==="student"?"Student account created successfully.":"Staff account created. The staff member can use Staff Login with the created college email. On the first login, the system will ask them to create their password.");
    }catch(e){setError(e.response?.data?.message||"Unable to save user.")}
    finally{setSaving(false)}
  };

  const remove=async u=>{
    if(u._id===user._id)return alert("You cannot delete your own admin account from this page.");
    if(!window.confirm(`Delete ${u.name}'s account? This cannot be undone.`))return;
    try{await API.delete(`/users/${u._id}`);await load()}catch(e){setError(e.response?.data?.message||"Unable to delete user.")}
  };

  const isStaffCreate=!editing&&["faculty","club_admin"].includes(form.role);
  const passwordRequired=!editing&&form.role==="student";

  return <div className="space-y-6">
    <PageHeader eyebrow="Super Admin" title="Student & Staff Management" description="Create KIOT student and staff accounts, update details, control access and manage all campus user records."/>

    <div className="flex flex-wrap gap-3">
      <button onClick={()=>openCreate("student")} className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-3 font-black text-white shadow-lg shadow-blue-600/20 hover:bg-blue-700"><FaPlus/> Create Student</button>
      <button onClick={()=>openCreate("faculty")} className="inline-flex items-center gap-2 rounded-xl bg-cyan-600 px-5 py-3 font-black text-white shadow-lg shadow-cyan-600/20 hover:bg-cyan-700"><FaChalkboardTeacher/> Create Staff / Faculty</button>
    </div>

    {error&&<div className="flex items-center justify-between rounded-2xl border border-red-200 bg-red-50 p-4 font-bold text-red-700"><span>{error}</span><button onClick={()=>setError("")}><FaTimes/></button></div>}

    <div className="grid gap-4 sm:grid-cols-3">
      <Summary icon={FaUsers} value={students.length} label="Students"/>
      <Summary icon={FaUserShield} value={staff.length} label="Staff / Faculty"/>
      <Summary icon={FaUserShield} value={data.filter(u=>u.role==="super_admin").length} label="Super Admins"/>
    </div>

    <div className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2">
          <Tab active={tab==="students"} onClick={()=>setTab("students")} text="Students" count={students.length}/>
          <Tab active={tab==="staff"} onClick={()=>setTab("staff")} text="Staff" count={staff.length}/>
          <Tab active={tab==="admins"} onClick={()=>setTab("admins")} text="Admins" count={data.filter(u=>u.role==="super_admin").length}/>
        </div>
        <div className="flex items-center gap-3 rounded-xl border border-slate-200 px-3 py-2.5 lg:w-[380px]"><FaSearch className="text-slate-400"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search name, email, department..." className="w-full outline-none font-semibold"/></div>
      </div>
    </div>

    <div className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm">
      <div className="overflow-x-auto">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-gradient-to-r from-blue-50 to-cyan-50 text-xs uppercase tracking-wider text-slate-500"><tr><th className="px-5 py-4">Person</th><th className="px-5 py-4">Role</th><th className="px-5 py-4">Academic / Work Details</th><th className="px-5 py-4">Login</th><th className="px-5 py-4">Actions</th></tr></thead>
          <tbody className="divide-y divide-slate-100">
            {loading?<tr><td colSpan="5" className="px-5 py-14 text-center font-bold text-slate-500">Loading records...</td></tr>:filtered.map(u=><tr key={u._id} className="hover:bg-slate-50">
              <td className="px-5 py-4"><div className="flex items-center gap-3"><Avatar name={u.name} image={u.profileImage||""} size="h-11 w-11"/><div><p className="font-black">{u.name}</p><p className="text-xs font-semibold text-slate-500">{u.email}</p><p className="text-xs font-semibold text-slate-400">{u.phone||"No phone"}</p></div></div></td>
              <td className="px-5 py-4"><span className="rounded-full bg-blue-50 px-3 py-1 text-xs font-black capitalize text-blue-700">{u.role==="faculty"?"Faculty":u.role?.replace("_"," ")}</span><p className={`mt-2 text-xs font-black ${u.isActive?"text-emerald-600":"text-red-600"}`}>{u.isActive?"Active":"Inactive"}</p>{u.mustSetPassword&&<p className="mt-1 text-xs font-black text-amber-600">First password pending</p>}</td>
              <td className="px-5 py-4"><p className="font-bold">{u.department||"—"}</p>{u.role==="student"?<p className="mt-1 text-xs text-slate-500">{u.year||""} {u.section?`• ${u.section}`:""} • Roll {u.rollNo||"—"} • UMIS {u.umis||"—"}</p>:<p className="mt-1 text-xs text-slate-500">{u.designation||"Staff"} {u.employeeId?`• ${u.employeeId}`:""} {u.qualification?`• ${u.qualification}`:""}</p>}</td>
              <td className="px-5 py-4"><p className="text-xs font-bold capitalize text-slate-500">{u.accountType|| (u.role==="student"?"student":"staff")}</p><p className="text-xs text-slate-400">{u.loginCount||0} logins</p></td>
              <td className="px-5 py-4"><div className="flex gap-2"><button onClick={()=>openEdit(u)} className="rounded-lg bg-amber-50 px-3 py-2 text-xs font-black text-amber-700"><FaEdit className="mr-1 inline"/>Edit</button>{u._id!==user._id&&<button onClick={()=>remove(u)} className="rounded-lg bg-red-50 px-3 py-2 text-xs font-black text-red-600"><FaTrash className="mr-1 inline"/>Delete</button>}</div></td>
            </tr>)}
            {!loading&&!filtered.length&&<tr><td colSpan="5" className="px-5 py-14 text-center font-bold text-slate-500">No records found.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>

    <Modal open={open} onClose={()=>!saving&&setOpen(false)} title={editing?`Update ${editing.role==="student"?"Student":"Staff"} Details`:form.role==="student"?"Create Student Account":"Create Staff / Faculty Account"} wide>
      <form onSubmit={save} className="space-y-4">
        <div className={`rounded-2xl p-4 text-sm font-semibold ${isStaffCreate?"bg-cyan-50 text-cyan-900":"bg-blue-50 text-blue-800"}`}>
          {editing?"Update any student or staff field. Leave Password blank to keep the current password.":isStaffCreate?"Staff account setup: enter the staff member's college details. Do not enter a password. The staff member will choose a password during their first Staff Login using this email address.":"Student account setup: enter the student's college credentials. A password is required for a student account."}
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full Name" value={form.name} onChange={v=>setForm({...form,name:v})} required/>
          <Field label="KIOT Email" value={form.email} onChange={v=>setForm({...form,email:v})} required/>
          <Field label={isStaffCreate?"Password (set by staff on first login)":editing?"New Password (optional)":"Password"} type="password" value={form.password} onChange={v=>setForm({...form,password:v})} required={passwordRequired}/>
          <Field label="Account Type" select value={form.role} onChange={v=>setForm({...form,role:v})} options={[
            {value:"student",label:"Student Account (Student Login)"},
            {value:"faculty",label:"Faculty Account (Staff Login + Staff Directory)"},
            {value:"club_admin",label:"Club Admin Account (Staff Login)"},
            {value:"super_admin",label:"Super Admin Account (Staff Login)"}
          ]}/>
          <Field label="Phone" value={form.phone} onChange={v=>setForm({...form,phone:v})}/>
          <Field label="Department" value={form.department} onChange={v=>setForm({...form,department:v})}/>
          <Field label="Year" value={form.year} onChange={v=>setForm({...form,year:v})}/>
          <Field label="Section" value={form.section} onChange={v=>setForm({...form,section:v})}/>
          <Field label="Roll No" value={form.rollNo} onChange={v=>setForm({...form,rollNo:v})}/>
          <Field label="UMIS" value={form.umis} onChange={v=>setForm({...form,umis:v})}/>
          <Field label="Batch" value={form.batch} onChange={v=>setForm({...form,batch:v})}/>
          <Field label="Designation" value={form.designation} onChange={v=>setForm({...form,designation:v})}/>
          <Field label="Qualification" value={form.qualification} onChange={v=>setForm({...form,qualification:v})}/>
          <Field label="Employee ID" value={form.employeeId} onChange={v=>setForm({...form,employeeId:v})}/>
        </div>
        <Field label="Subjects (comma separated)" value={form.subjects} onChange={v=>setForm({...form,subjects:v})}/>
        <Field label="Skills (comma separated)" value={form.skills} onChange={v=>setForm({...form,skills:v})}/>
        <Field label="Bio" textarea value={form.bio} onChange={v=>setForm({...form,bio:v})}/>
        <label className="flex items-center gap-3 rounded-xl bg-slate-50 p-3 font-bold"><input type="checkbox" checked={!!form.isActive} onChange={e=>setForm({...form,isActive:e.target.checked})} className="h-4 w-4"/> Account is active</label>
        <button disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-black text-white disabled:opacity-60"><FaSave/>{saving?"Saving...":editing?"Update Details":form.role==="student"?"Create Student":"Create Staff Account"}</button>
      </form>
    </Modal>
  </div>;
}

function Summary({icon:Icon,value,label}){return <div className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm"><div className="flex items-center gap-3"><div className="flex h-11 w-11 items-center justify-center rounded-xl bg-blue-50 text-blue-600"><Icon/></div><div><p className="text-2xl font-black">{value}</p><p className="text-xs font-bold text-slate-400">{label}</p></div></div></div>}
function Tab({active,onClick,text,count}){return <button onClick={onClick} className={`rounded-xl px-4 py-2.5 text-sm font-black ${active?"bg-blue-600 text-white":"bg-slate-100 text-slate-600"}`}>{text} <span className="ml-1 opacity-70">{count}</span></button>}
function Field({label,value,onChange,type="text",textarea,select,options=[],required}){return <label className="block"><span className="mb-1.5 block text-sm font-black text-slate-700">{label}</span>{select?<select required={required} value={value} onChange={e=>onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold">{options.map(o=><option key={o.value} value={o.value}>{o.label}</option>)}</select>:textarea?<textarea required={required} rows="4" value={value||""} onChange={e=>onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold"/>:<input required={required} type={type} value={value||""} onChange={e=>onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold"/>}</label>}
