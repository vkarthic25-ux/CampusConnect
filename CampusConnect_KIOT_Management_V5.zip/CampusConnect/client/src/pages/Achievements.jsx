import React, { useEffect, useState } from "react";
import { FaTrophy, FaCalendarAlt, FaPlus, FaTrash, FaMedal } from "react-icons/fa";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import PageHeader from "../components/common/PageHeader";
import Modal from "../components/common/Modal";

const blank = { title: "", description: "", category: "Technical", date: "" };

export default function Achievements() {
  const { user } = useAuth();
  const [data, setData] = useState([]); const [open, setOpen] = useState(false); const [form, setForm] = useState(blank); const [loading, setLoading] = useState(false); const [error, setError] = useState("");
  const load = async () => { try { const r = await API.get("/achievements"); setData(r.data?.data || []); setError(""); } catch (e) { setError(e.response?.data?.message || "Unable to load achievements."); } };
  useEffect(() => { load(); }, []);
  const add = async (e) => { e.preventDefault(); try { setLoading(true); await API.post("/achievements", form); setOpen(false); setForm(blank); await load(); } catch (err) { alert(err.response?.data?.message || "Unable to save achievement."); } finally { setLoading(false); } };
  const del = async (id) => { if (!window.confirm("Delete this achievement?")) return; try { await API.delete(`/achievements/${id}`); await load(); } catch (e) { alert(e.response?.data?.message || "Unable to delete achievement."); } };
  const mine = data.filter((a) => (a.user?._id || a.user)?.toString() === user?._id?.toString());

  return <div className="space-y-6">
    <PageHeader title="My Achievements" description="Showcase academic, technical, cultural, sports, certification and hackathon achievements." buttonText="Add Achievement" onClick={() => setOpen(true)} />
    {error && <div className="rounded-2xl border border-red-200 bg-red-50 p-4 font-semibold text-red-700">{error}</div>}
    <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
      {mine.length ? mine.map((a) => <article key={a._id} className="group overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl"><div className="relative flex h-32 items-center justify-center overflow-hidden bg-gradient-to-br from-blue-950 via-indigo-700 to-cyan-500"><div className="absolute h-32 w-32 rounded-full border border-white/20" /><FaTrophy className="relative text-5xl text-white drop-shadow-lg" /></div><div className="p-5"><div className="flex items-start justify-between gap-3"><div><span className="rounded-full bg-blue-50 px-2.5 py-1 text-[11px] font-black text-blue-700">{a.category}</span><h3 className="mt-3 text-lg font-black">{a.title}</h3></div><button onClick={() => del(a._id)} className="rounded-lg p-2 text-slate-400 hover:bg-red-50 hover:text-red-600"><FaTrash /></button></div><p className="mt-2 line-clamp-3 text-sm leading-6 text-slate-500">{a.description || "Achievement added to your KIOT profile."}</p><div className="mt-4 flex items-center gap-2 text-xs font-bold text-slate-400"><FaCalendarAlt />{a.date ? new Date(a.date).toLocaleDateString() : "Date not set"}</div></div></article>) : <div className="md:col-span-2 xl:col-span-3 rounded-3xl border-2 border-dashed border-slate-200 bg-white p-14 text-center"><FaMedal className="mx-auto text-5xl text-blue-200" /><h3 className="mt-4 text-xl font-black">No achievements yet</h3><p className="mt-1 text-slate-500">Add your first achievement to your CampusConnect profile.</p><button onClick={() => setOpen(true)} className="mt-5 inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-3 font-black text-white"><FaPlus /> Add Achievement</button></div>}
    </div>
    <Modal open={open} onClose={() => !loading && setOpen(false)} title="Add Achievement"><form onSubmit={add} className="space-y-4"><Field label="Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} required /><Field label="Description" value={form.description} onChange={(v) => setForm({ ...form, description: v })} textarea /><Field label="Category" select value={form.category} onChange={(v) => setForm({ ...form, category: v })} options={["Academic", "Technical", "Hackathon", "Sports", "Cultural", "Certification", "Competition", "Other"]} /><Field label="Date" value={form.date} onChange={(v) => setForm({ ...form, date: v })} type="date" /><button disabled={loading} className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-black text-white disabled:opacity-60">{loading ? "Saving..." : "Save Achievement"}</button></form></Modal>
  </div>;
}
function Field({ label, value, onChange, textarea, select, options = [], required, type = "text" }) { return <label className="block"><span className="mb-1.5 block text-sm font-black">{label}</span>{select ? <select required={required} value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5">{options.map((x) => <option key={x}>{x}</option>)}</select> : textarea ? <textarea rows="4" value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5" /> : <input required={required} type={type} value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-2.5" />}</label>; }
