import React, { useEffect, useState } from "react";
import { FaBell, FaCheck, FaCalendarCheck, FaUsers, FaPaperPlane, FaTimes } from "react-icons/fa";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import PageHeader from "../components/common/PageHeader";
import Modal from "../components/common/Modal";

const departments = ["All Departments", "CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "AIDS", "AIML", "MBA"];
const empty = { title: "", message: "", audience: "all", department: "All Departments" };

export default function Notifications() {
  const { user } = useAuth();
  const [data, setData] = useState([]);
  const [error, setError] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(empty);
  const [sending, setSending] = useState(false);

  const load = async () => {
    try { const r = await API.get("/notifications"); setData(r.data?.data || []); setError(""); }
    catch (e) { setError(e.response?.data?.message || "Unable to load notifications."); }
  };
  useEffect(() => { load(); }, []);

  const read = async (id) => { try { await API.put(`/notifications/${id}/read`); await load(); } catch (e) { setError(e.response?.data?.message || "Unable to mark notification as read."); } };
  const all = async () => { try { await API.put("/notifications/read-all"); await load(); } catch (e) { setError(e.response?.data?.message || "Unable to update notifications."); } };
  const send = async (e) => {
    e.preventDefault(); setSending(true); setError("");
    try { const r = await API.post("/notifications/send", form); alert(r.data?.message || "Notification sent"); setOpen(false); setForm(empty); }
    catch (e) { setError(e.response?.data?.message || "Unable to send notification."); }
    finally { setSending(false); }
  };
  const icon = (type) => type === "event" ? <FaCalendarCheck /> : type === "club" ? <FaUsers /> : <FaBell />;

  return <div className="space-y-6">
    <PageHeader title="Notifications" description="View your notifications. Super Admin can send targeted notifications to students, staff or a department." buttonText={user?.role === "super_admin" ? "Send Notification" : undefined} onClick={() => setOpen(true)} />
    {error && <div className="flex items-center justify-between rounded-2xl border border-red-200 bg-red-50 p-4 font-semibold text-red-700"><span>{error}</span><button onClick={() => setError("")}><FaTimes /></button></div>}
    <div className="flex items-center justify-between rounded-2xl border border-slate-200 bg-white p-4 shadow-sm"><div><p className="text-sm font-black text-slate-800">{data.filter((n) => !n.isRead).length} unread notifications</p><p className="text-xs text-slate-400">Admin messages and CampusConnect activity appear here.</p></div><button onClick={all} className="inline-flex items-center gap-2 rounded-xl bg-slate-50 px-4 py-2.5 text-sm font-black text-slate-700 hover:bg-blue-50 hover:text-blue-700"><FaCheck /> Mark all read</button></div>
    <div className="space-y-3">{data.length ? data.map((n) => <div key={n._id} className={`rounded-2xl border p-4 shadow-sm transition ${n.isRead ? "border-slate-200 bg-white" : "border-blue-200 bg-blue-50/40 shadow-blue-100"}`}><div className="flex gap-4"><div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-gradient-to-br from-blue-600 to-cyan-500 text-white">{icon(n.type)}</div><div className="min-w-0 flex-1"><div className="flex items-center justify-between gap-3"><h3 className="font-black text-slate-800">{n.title}</h3>{!n.isRead && <span className="h-2.5 w-2.5 rounded-full bg-blue-600" />}</div><p className="mt-1 text-sm leading-6 text-slate-600">{n.message}</p><p className="mt-2 text-xs font-semibold text-slate-400">{n.createdAt ? new Date(n.createdAt).toLocaleString() : "Recently"}</p></div>{!n.isRead && <button onClick={() => read(n._id)} className="self-center rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-700">Read</button>}</div></div>) : <div className="rounded-3xl border-2 border-dashed border-slate-200 bg-white p-14 text-center"><FaBell className="mx-auto text-5xl text-blue-200" /><h3 className="mt-4 text-xl font-black">You&apos;re all caught up</h3><p className="mt-1 text-slate-500">New admin and campus activity notifications will appear here.</p></div>}</div>

    <Modal open={open} onClose={() => !sending && setOpen(false)} title="Send Notification to Users" wide>
      <form onSubmit={send} className="space-y-4">
        <Field label="Notification Title" value={form.title} onChange={v => setForm({ ...form, title: v })} required />
        <Field label="Message" textarea value={form.message} onChange={v => setForm({ ...form, message: v })} required />
        <div className="grid gap-4 sm:grid-cols-2"><Field label="Send To" select value={form.audience} onChange={v => setForm({ ...form, audience: v })} options={[{ value: "all", label: "All Students & Staff" }, { value: "students", label: "Students Only" }, { value: "staff", label: "Staff / Faculty Only" }]} /><Field label="Department" select value={form.department} onChange={v => setForm({ ...form, department: v })} options={departments.map(d => ({ value: d, label: d }))} /></div>
        <div className="rounded-2xl bg-blue-50 p-4 text-sm font-semibold text-blue-800">Only Super Admin can send admin notifications. Messages are stored in MongoDB and appear in each recipient&apos;s Notifications tab.</div>
        <button disabled={sending} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-black text-white disabled:opacity-60"><FaPaperPlane />{sending ? "Sending..." : "Send Notification"}</button>
      </form>
    </Modal>
  </div>;
}

function Field({ label, value, onChange, textarea, select, options = [], required }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-black text-slate-700">{label}</span>{select ? <select required={required} value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold">{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select> : textarea ? <textarea required={required} rows="6" value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold" /> : <input required={required} value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold" />}</label>;
}
