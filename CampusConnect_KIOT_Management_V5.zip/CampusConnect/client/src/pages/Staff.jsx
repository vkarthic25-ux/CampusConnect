import React,{useEffect,useMemo,useState} from "react";
import {FaChalkboardTeacher,FaEnvelope,FaPhone,FaGraduationCap,FaIdBadge,FaSearch,FaFilter,FaTimes} from "react-icons/fa";
import API from "../services/api";
import PageHeader from "../components/common/PageHeader";
import Avatar from "../components/common/Avatar";

const departments=["All Departments","CSE","ECE","EEE","MECH","CIVIL","IT","AIDS","AIML","MBA"];

export default function Staff(){
  const[data,setData]=useState([]),[q,setQ]=useState(""),[department,setDepartment]=useState("All Departments"),[designation,setDesignation]=useState("All Designations"),[loading,setLoading]=useState(true),[error,setError]=useState("");
  const load=async()=>{
    try{setLoading(true);const r=await API.get("/staff",{params:{q,department,designation}});setData(r.data?.data||[]);setError("");}
    catch(e){setError(e.response?.data?.message||"Unable to load staff");}
    finally{setLoading(false);}
  };
  useEffect(()=>{const t=setTimeout(load,250);return()=>clearTimeout(t);},[q,department,designation]);
  const designations=useMemo(()=>["All Designations",...Array.from(new Set(data.map(x=>x.designation).filter(Boolean))).sort()], [data]);
  const clear=()=>{setQ("");setDepartment("All Departments");setDesignation("All Designations");};
  return <div className="space-y-6">
    <PageHeader eyebrow="Faculty & Staff" title="Staff Directory" description="Find KIOT faculty and staff created by the administrator. Search and filter by department or designation."/>
    {error&&<div className="rounded-2xl border border-red-200 bg-red-50 p-4 font-bold text-red-700">{error}</div>}
    <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
      <div className="grid gap-3 lg:grid-cols-[1.4fr_.8fr_.8fr_auto]">
        <div className="flex items-center gap-3 rounded-2xl border border-slate-200 px-4"><FaSearch className="text-slate-400"/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search faculty by name, email, department, subject..." className="w-full py-3.5 text-base font-semibold outline-none"/></div>
        <div className="flex items-center gap-2 rounded-2xl border border-slate-200 px-3"><FaFilter className="text-slate-400"/><select value={department} onChange={e=>setDepartment(e.target.value)} className="w-full bg-transparent py-3.5 font-bold outline-none">{departments.map(x=><option key={x}>{x}</option>)}</select></div>
        <div className="flex items-center gap-2 rounded-2xl border border-slate-200 px-3"><FaChalkboardTeacher className="text-slate-400"/><select value={designation} onChange={e=>setDesignation(e.target.value)} className="w-full bg-transparent py-3.5 font-bold outline-none">{designations.map(x=><option key={x}>{x}</option>)}</select></div>
        <button onClick={clear} className="rounded-2xl bg-slate-100 px-5 py-3.5 font-black text-slate-700 hover:bg-blue-50 hover:text-blue-700"><FaTimes className="mr-2 inline"/>Clear</button>
      </div>
      <div className="mt-4 flex flex-wrap gap-2 text-sm font-bold text-slate-500"><span className="rounded-full bg-blue-50 px-3 py-1.5 text-blue-700">{data.length} staff found</span>{department!=="All Departments"&&<span className="rounded-full bg-slate-100 px-3 py-1.5">Department: {department}</span>}</div>
    </div>
    {loading?<div className="rounded-3xl bg-white p-14 text-center font-bold text-slate-500 shadow-sm">Loading staff directory...</div>:<div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{data.map(s=><article key={s._id} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm hover:shadow-xl"><div className="h-24 bg-gradient-to-r from-blue-950 via-blue-700 to-cyan-500"/><div className="px-5 pb-5"><div className="-mt-12 flex items-end justify-between"><Avatar name={s.name} image={s.profileImage||""} size="h-24 w-24" textSize="text-4xl"/><span className="rounded-full bg-white px-3 py-1.5 text-xs font-black capitalize text-blue-700 shadow">{s.role==="faculty"?"Faculty":s.role.replace("_"," ")}</span></div><h2 className="mt-4 text-2xl font-black">{s.name}</h2><p className="mt-1 font-bold text-blue-600">{s.designation||"Faculty / Staff"}</p><p className="mt-1 text-sm font-bold text-slate-500">Department: {s.department||"KIOT"}</p><div className="mt-4 space-y-2 text-sm font-semibold text-slate-600"><p><FaGraduationCap className="mr-2 inline text-blue-600"/>{s.qualification||"Qualification not added"}</p><p><FaEnvelope className="mr-2 inline text-blue-600"/>{s.email}</p>{s.phone&&<p><FaPhone className="mr-2 inline text-blue-600"/>{s.phone}</p>}{s.employeeId&&<p><FaIdBadge className="mr-2 inline text-blue-600"/>Employee ID: {s.employeeId}</p>}</div>{s.bio&&<p className="mt-4 rounded-2xl bg-slate-50 p-3 text-sm leading-6 text-slate-500">{s.bio}</p>}<div className="mt-4 flex flex-wrap gap-2">{(s.subjects||[]).map(x=><span key={x} className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-bold text-emerald-700">{x}</span>)}{(s.skills||[]).map(x=><span key={x} className="rounded-full bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700">{x}</span>)}</div></div></article>)}</div>}
    {!loading&&!data.length&&<div className="rounded-3xl border-2 border-dashed border-slate-200 bg-white p-14 text-center font-bold text-slate-500">No faculty or staff matched the current filters.</div>}
  </div>
}
