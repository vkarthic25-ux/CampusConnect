import React,{useEffect,useState} from "react";
import {Link,useLocation,useNavigate} from "react-router-dom";
import {FaArrowRight,FaEnvelope,FaLock,FaUserGraduate,FaChalkboardTeacher,FaCheckCircle,FaKey} from "react-icons/fa";
import {useAuth} from "../../context/AuthContext";
import {authAPI} from "../../services/api";

export default function Login({initialType=""}){
  const location=useLocation(), nav=useNavigate(), {login}=useAuth();
  const queryType=new URLSearchParams(location.search).get("type");
  const [accountType,setAccountType]=useState(initialType||queryType||"");
  const [email,setEmail]=useState("");
  const [password,setPassword]=useState("");
  const [confirmPassword,setConfirmPassword]=useState("");
  const [setupToken,setSetupToken]=useState("");
  const [mode,setMode]=useState("email");
  const [error,setError]=useState("");
  const [info,setInfo]=useState("");
  const [busy,setBusy]=useState(false);

  useEffect(()=>{
    if(initialType){
      setAccountType(initialType);
      setEmail("");
      setPassword("");
      setConfirmPassword("");
      setSetupToken("");
      setMode(initialType==="staff"?"email":"login");
    }
  },[initialType]);

  const choose=(type)=>{
    setAccountType(type);setError("");setInfo("");setEmail("");setPassword("");setConfirmPassword("");setSetupToken("");setMode(type==="staff"?"email":"login");
  };

  const continueStaff=async()=>{
    setError("");setInfo("");
    if(!/^[^\s@]+@kiot\.ac\.in$/i.test(email))return setError("Use your @kiot.ac.in college email.");
    try{
      setBusy(true);
      const r=await authAPI.checkStaff({email});
      if(r.data?.requiresPasswordSetup){
        setSetupToken(r.data.setupToken);
        setPassword("");setConfirmPassword("");
        setMode("setup");
        setInfo("This is your first staff login. Create your personal password below.");
      }else{
        setMode("login");
        setInfo("Staff account found. Enter the password for this account.");
      }
    }catch(e){setError(e.response?.data?.message||"Unable to check staff account.")}
    finally{setBusy(false)}
  };

  const createPassword=async(e)=>{
    e.preventDefault();setError("");setInfo("");
    if(password!==confirmPassword)return setError("Passwords do not match.");
    try{
      setBusy(true);
      await authAPI.setFirstStaffPassword({email,password,confirmPassword,setupToken});
      setInfo("Password created successfully. You can now sign in with your staff email and password.");
      setPassword("");setConfirmPassword("");setSetupToken("");setMode("login");
    }catch(e){setError(e.response?.data?.message||"Unable to create password.")}
    finally{setBusy(false)}
  };

  const submit=async e=>{
    e.preventDefault();setError("");setInfo("");
    if(!accountType)return setError("Please choose Student or Staff login first.");
    if(!/^[^\s@]+@kiot\.ac\.in$/i.test(email))return setError("Use your @kiot.ac.in college email.");
    try{
      setBusy(true);
      const user=await login(email,password,accountType);
      nav(user?.role==="student"?"/student-home":"/staff-home",{replace:true});
    }catch(e){setError(e.response?.data?.message||"Login failed")}
    finally{setBusy(false)}
  };

  const showPasswordLogin=accountType!=="staff"||mode==="login";

  return <div className="auth-background min-h-screen bg-cover bg-center p-4 sm:p-8"><div className="mx-auto flex min-h-[calc(100vh-2rem)] max-w-6xl items-center justify-center"><div className="grid w-full overflow-hidden rounded-[32px] bg-white shadow-2xl lg:grid-cols-[1.05fr_.95fr]">
    <div className="hidden bg-gradient-to-br from-[#07152f] via-[#0a2c62] to-[#0a7da3] p-10 text-white lg:block"><img src="/assets/kiot-banner.jpg" className="h-44 w-full rounded-2xl object-cover object-top"/><p className="mt-9 text-xs font-black uppercase tracking-[.25em] text-cyan-200">Knowledge Institute of Technology</p><h1 className="mt-2 text-4xl font-black">CampusConnect</h1><p className="mt-4 max-w-md text-base leading-7 text-blue-100">Students use Student Login. Faculty and staff created by the administrator use Staff Login. New staff create their password during first-time login.</p><div className="mt-8 space-y-3"><Info text="Students open the student campus workspace"/><Info text="Admin-created faculty accounts appear in the Staff Directory"/><Info text="Every successful login is recorded in MongoDB"/></div></div>
    <div className="p-7 sm:p-10"><img src="/assets/college-logo.svg" className="h-16 w-16"/><p className="mt-6 text-xs font-black uppercase tracking-[.2em] text-blue-600">KIOT College Community Portal</p><h2 className="mt-2 text-3xl font-black text-slate-900">Sign in to CampusConnect</h2><p className="mt-2 text-base font-semibold text-slate-500">Choose Student or Staff. Staff accounts created by the admin can create their password the first time they sign in.</p>
      <div className="mt-7 grid grid-cols-2 gap-3"><TypeButton active={accountType==="student"} onClick={()=>choose("student")} icon={FaUserGraduate} title="Student" text="Student account"/><TypeButton active={accountType==="staff"} onClick={()=>choose("staff")} icon={FaChalkboardTeacher} title="Staff" text="Faculty / Staff"/></div>
      {accountType&&<div className="mt-7">
        <div className="rounded-2xl border border-blue-100 bg-blue-50 p-4"><p className="text-xs font-black uppercase tracking-widest text-blue-600">Selected login</p><p className="mt-1 text-lg font-black capitalize text-blue-950">{accountType} Login</p><p className="text-sm font-semibold text-blue-700">{accountType==="staff"?mode==="setup"?"Create your password for this first staff login.":mode==="email"?"Enter your staff email to continue.":"Enter the password already created for this staff account.":"Enter your student college email and password."}</p></div>
        {error&&<div className="mt-5 rounded-xl bg-red-50 p-3 text-sm font-bold text-red-700">{error}</div>}
        {info&&<div className="mt-5 rounded-xl bg-emerald-50 p-3 text-sm font-bold text-emerald-700">{info}</div>}

        {accountType==="staff"&&mode==="setup"?<form onSubmit={createPassword} className="mt-5">
          <label className="block text-base font-black">College Email<div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 px-3 bg-slate-50"><FaEnvelope className="text-slate-400"/><input value={email} readOnly className="w-full bg-transparent py-3.5 font-semibold outline-none"/></div></label>
          <label className="mt-4 block text-base font-black">Create Password<div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 px-3"><FaKey className="text-slate-400"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full bg-transparent py-3.5 font-semibold outline-none" placeholder="Minimum 8 chars, upper, lower and number"/></div></label>
          <label className="mt-4 block text-base font-black">Confirm Password<div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 px-3"><FaLock className="text-slate-400"/><input type="password" value={confirmPassword} onChange={e=>setConfirmPassword(e.target.value)} className="w-full bg-transparent py-3.5 font-semibold outline-none"/></div></label>
          <button disabled={busy} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 py-4 text-base font-black text-white disabled:opacity-60">{busy?"Creating password...":"Create Staff Password"}<FaArrowRight/></button>
        </form>:
        <form onSubmit={accountType==="staff"&&mode==="email"?(e)=>{e.preventDefault();continueStaff();}:submit} className="mt-5">
          <label className="block text-base font-black">College Email<div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 px-3"><FaEnvelope className="text-slate-400"/><input value={email} onChange={e=>setEmail(e.target.value)} className="w-full bg-transparent py-3.5 font-semibold outline-none" placeholder="name@kiot.ac.in"/></div></label>
          {showPasswordLogin&&<label className="mt-4 block text-base font-black">Password<div className="mt-2 flex items-center gap-3 rounded-xl border border-slate-200 px-3"><FaLock className="text-slate-400"/><input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="w-full bg-transparent py-3.5 font-semibold outline-none" placeholder="Enter password"/></div></label>}
          <button disabled={busy} className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-4 text-base font-black text-white shadow-lg shadow-blue-600/20 disabled:opacity-60">{busy?(accountType==="staff"&&mode==="email"?"Checking staff account...":"Signing in..."):(accountType==="staff"&&mode==="email"?"Continue with Staff Email":`Sign in as ${accountType}`)}<FaArrowRight/></button>
        </form>}

        {accountType==="staff"&&mode!=="setup"&&<button onClick={()=>{setMode("email");setPassword("");setError("");setInfo("")}} className="mt-4 text-sm font-black text-blue-600 hover:underline">Use a different staff email</button>}
      </div>}
      {!accountType&&<div className="mt-7 rounded-2xl border-2 border-dashed border-slate-200 p-7 text-center"><p className="text-lg font-black text-slate-800">Choose Student or Staff</p><p className="mt-1 text-sm font-semibold text-slate-500">The correct dashboard will open automatically after login.</p></div>}
      <p className="mt-6 text-center text-base font-semibold text-slate-600">New to CampusConnect? <Link className="font-black text-blue-600" to="/register">Create student account</Link></p>
    </div></div></div></div>
}
function Info({text}){return <div className="flex items-center gap-3 rounded-xl bg-white/10 p-3 text-sm font-bold"><FaCheckCircle className="text-cyan-300"/>{text}</div>}
function TypeButton({active,onClick,icon:Icon,title,text}){return <button type="button" onClick={onClick} className={`rounded-2xl border-2 p-4 text-left transition ${active?"border-blue-600 bg-blue-600 text-white shadow-lg":"border-slate-200 bg-white hover:border-blue-300 hover:bg-blue-50"}`}><Icon className={`text-2xl ${active?"text-cyan-200":"text-blue-600"}`}/><p className="mt-2 text-lg font-black">{title}</p><p className={`text-xs font-bold ${active?"text-blue-100":"text-slate-500"}`}>{text}</p></button>}
