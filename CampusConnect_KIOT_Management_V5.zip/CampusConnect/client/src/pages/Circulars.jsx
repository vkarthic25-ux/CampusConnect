import React, { useEffect, useState } from "react";
import { FaBullhorn, FaDownload, FaEdit, FaFileAlt, FaPlus, FaTrash, FaTimes } from "react-icons/fa";
import API from "../services/api";
import { useAuth } from "../context/AuthContext";
import PageHeader from "../components/common/PageHeader";
import Modal from "../components/common/Modal";

const empty = { title: "", content: "", audience: "all", department: "All Departments", attachmentName: "", attachmentType: "", attachmentData: "" };
const departments = ["All Departments", "CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "AIDS", "AIML", "MBA"];

export default function Circulars() {
  const { user } = useAuth();
  const [data, setData] = useState([]);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(empty);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");
  const canPublish = ["super_admin", "faculty", "club_admin"].includes(user?.role);

  const load = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const r = await API.get("/circulars", { params: { department: user.department || "" } });
      setData(r.data?.data || []);
      setError("");
    } catch (e) {
      setError(e.response?.data?.message || "Unable to load circulars.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [user?._id, user?.department]);

  const close = () => {
    setOpen(false);
    setEditing(null);
    setForm(empty);
  };

  const upload = (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (file.size > 9 * 1024 * 1024) {
      setError("Please choose a file smaller than 9 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setForm((x) => ({
      ...x,
      attachmentName: file.name,
      attachmentType: file.type || "application/octet-stream",
      attachmentData: String(reader.result).split(",")[1] || "",
    }));
    reader.readAsDataURL(file);
  };

  const submit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError("");
    try {
      const payload = { ...form };
      if (editing && !payload.attachmentData) delete payload.attachmentData;
      const response = editing
        ? await API.put(`/circulars/${editing._id}`, payload)
        : await API.post("/circulars", payload);
      const saved = response.data?.data;
      if (saved?._id) {
        setData((current) => editing
          ? current.map((item) => item._id === saved._id ? saved : item)
          : [saved, ...current]);
      }
      close();
      await load();
    } catch (e) {
      setError(e.response?.data?.message || "Unable to save circular.");
    } finally {
      setSaving(false);
    }
  };

  const edit = (c) => {
    setEditing(c);
    setForm({
      title: c.title || "",
      content: c.content || "",
      audience: c.audience || "all",
      department: c.department || "All Departments",
      attachmentName: c.attachmentName || "",
      attachmentType: c.attachmentType || "",
      attachmentData: "",
    });
    setOpen(true);
  };

  const del = async (id) => {
    if (!window.confirm("Delete this circular?")) return;
    try {
      await API.delete(`/circulars/${id}`);
      setData((current) => current.filter((item) => item._id !== id));
      await load();
    } catch (e) {
      setError(e.response?.data?.message || "Unable to delete circular.");
    }
  };

  const download = async (c) => {
    try {
      const r = await API.get(`/circulars/${c._id}/download`, { responseType: "blob" });
      const url = URL.createObjectURL(r.data);
      const a = document.createElement("a");
      a.href = url;
      a.download = c.attachmentName || "circular-file";
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch (e) {
      setError(e.response?.data?.message || "Unable to download attachment.");
    }
  };

  const openCreate = () => {
    setEditing(null);
    setForm(empty);
    setOpen(true);
  };

  return <div className="space-y-6">
    <PageHeader
      eyebrow="Official KIOT notices"
      title="Circulars"
      description="Read and publish official college circulars, academic notices and important instructions."
      buttonText={canPublish ? "Upload Circular" : undefined}
      onClick={canPublish ? openCreate : undefined}
    />

    {error && <div className="flex items-center justify-between rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-bold text-red-700"><span>{error}</span><button onClick={() => setError("")}><FaTimes /></button></div>}

    {loading ? <div className="rounded-3xl bg-white p-12 text-center font-bold text-slate-500 shadow-sm">Loading circulars...</div> : data.length ? (
      <div className="grid gap-5 lg:grid-cols-2">
        {data.map((c) => <article key={c._id} className="overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-sm transition hover:-translate-y-1 hover:shadow-xl">
          <div className="bg-gradient-to-r from-blue-950 via-blue-700 to-cyan-500 p-5 text-white">
            <div className="flex items-center justify-between gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/15 text-xl"><FaBullhorn /></div>
              <span className="rounded-full bg-white/15 px-3 py-1 text-xs font-black capitalize">{c.audience === "all" ? "Everyone" : c.audience}</span>
            </div>
            <h2 className="mt-5 text-2xl font-black">{c.title}</h2>
            <p className="mt-1 text-sm font-bold text-blue-100">{c.department || "All Departments"}</p>
          </div>
          <div className="p-5">
            <p className="whitespace-pre-line text-sm font-semibold leading-7 text-slate-600">{c.content}</p>
            <div className="mt-5 flex flex-wrap items-center gap-2 text-xs font-bold text-slate-500">
              <span className="rounded-full bg-slate-100 px-3 py-1">By {c.createdBy?.name || "KIOT Staff"}</span>
              <span className="rounded-full bg-slate-100 px-3 py-1">{c.createdAt ? new Date(c.createdAt).toLocaleDateString() : "Recently"}</span>
            </div>
            {c.attachmentName && <button onClick={() => download(c)} className="mt-4 flex w-full items-center gap-3 rounded-2xl border border-blue-100 bg-blue-50 p-3 text-left hover:bg-blue-100"><FaFileAlt className="text-blue-600"/><div className="min-w-0 flex-1"><p className="truncate text-sm font-black text-slate-800">{c.attachmentName}</p><p className="text-xs font-semibold text-slate-500">Download circular attachment</p></div><FaDownload className="text-blue-600"/></button>}
            {canPublish && (user?.role === "super_admin" || c.createdBy?._id === user?._id) && <div className="mt-4 flex gap-2"><button onClick={() => edit(c)} className="flex-1 rounded-xl bg-amber-50 py-2.5 text-sm font-black text-amber-700"><FaEdit className="mr-1 inline"/>Edit</button><button onClick={() => del(c._id)} className="rounded-xl bg-red-50 px-4 py-2.5 text-red-600"><FaTrash /></button></div>}
          </div>
        </article>)}
      </div>
    ) : <div className="rounded-3xl border-2 border-dashed border-slate-200 bg-white p-14 text-center"><FaBullhorn className="mx-auto text-5xl text-blue-200"/><h3 className="mt-4 text-xl font-black">No circulars published</h3><p className="mt-1 text-sm font-semibold text-slate-500">Official notices uploaded by staff or administration will appear here.</p></div>}

    <Modal open={open} onClose={() => !saving && close()} title={editing ? "Update Circular" : "Upload Circular"} wide>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Circular Title" value={form.title} onChange={(v) => setForm({ ...form, title: v })} required />
        <Field label="Circular Content" textarea value={form.content} onChange={(v) => setForm({ ...form, content: v })} required />
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Audience" select value={form.audience} onChange={(v) => setForm({ ...form, audience: v })} options={[{ value: "all", label: "All Students & Staff" }, { value: "students", label: "Students Only" }, { value: "staff", label: "Staff Only" }]} />
          <Field label="Department" select value={form.department} onChange={(v) => setForm({ ...form, department: v })} options={departments.map((d) => ({ value: d, label: d }))} />
        </div>
        <label className="block"><span className="mb-1.5 block text-sm font-black">Attachment (PDF / DOC / Image)</span><input type="file" accept=".pdf,.doc,.docx,.txt,.png,.jpg,.jpeg" onChange={upload} className="w-full rounded-xl border border-slate-200 p-3 text-sm font-semibold"/>{form.attachmentName && <p className="mt-2 rounded-xl bg-blue-50 p-3 text-sm font-bold text-blue-700">Selected: {form.attachmentName}</p>}</label>
        <button disabled={saving} className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-black text-white disabled:opacity-60"><FaPlus />{saving ? "Saving..." : editing ? "Update Circular" : "Publish Circular"}</button>
      </form>
    </Modal>
  </div>;
}

function Field({ label, value, onChange, textarea, select, options = [], required }) {
  return <label className="block"><span className="mb-1.5 block text-sm font-black text-slate-700">{label}</span>{select ? <select required={required} value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold">{options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}</select> : textarea ? <textarea required={required} rows="7" value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold" /> : <input required={required} value={value} onChange={e => onChange(e.target.value)} className="w-full rounded-xl border border-slate-200 px-3 py-3 font-semibold" />}</label>;
}
