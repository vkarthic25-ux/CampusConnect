import axios from 'axios';

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  timeout: 10000,
});

API.interceptors.request.use((config) => {
  const token = localStorage.getItem('campusconnect_token');
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

export const authAPI = {
  register: (data) => API.post('/auth/register', data),
  login: (data) => API.post('/auth/login', data),
  checkStaff: (data) => API.post('/auth/staff/check', data),
  setFirstStaffPassword: (data) => API.post('/auth/staff/set-first-password', data),
  logout: () => API.post('/auth/logout'),
  me: () => API.get('/auth/me'),
};

export default API;
