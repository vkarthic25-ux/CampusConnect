import React,{createContext,useContext,useEffect,useState}from"react";import{authAPI}from"../services/api";
const C=createContext(null);
export function AuthProvider({children}){
 const[user,setUser]=useState(()=>{try{return JSON.parse(localStorage.getItem("campusconnect_user"))||null}catch{return null}}),[loading,setLoading]=useState(true);
 const save=(u,t)=>{localStorage.setItem("campusconnect_token",t);localStorage.setItem("campusconnect_user",JSON.stringify(u));setUser(u)};
 const updateUser=(u)=>{localStorage.setItem("campusconnect_user",JSON.stringify(u));setUser(u)};
 const login=async(e,p,accountType)=>{const r=await authAPI.login({email:e,password:p,accountType});save(r.data.data.user,r.data.data.token);return r.data.data.user};
 const register=async(d)=>{const r=await authAPI.register(d);save(r.data.data.user,r.data.data.token);return r.data.data.user};
 const logout=async()=>{try{await authAPI.logout()}catch{}localStorage.removeItem("campusconnect_token");localStorage.removeItem("campusconnect_user");setUser(null)};
 useEffect(()=>{if(localStorage.getItem("campusconnect_token"))authAPI.me().then(r=>updateUser(r.data.data.user)).catch(logout).finally(()=>setLoading(false));else setLoading(false)},[]);
 return <C.Provider value={{user,loading,login,register,logout,updateUser,isAuthenticated:!!user}}>{children}</C.Provider>;
}
export const useAuth=()=>useContext(C);
