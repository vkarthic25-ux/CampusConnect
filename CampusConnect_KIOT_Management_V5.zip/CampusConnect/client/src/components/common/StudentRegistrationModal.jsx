import React, { useEffect, useState } from "react";
import { FaUserGraduate, FaCheckCircle } from "react-icons/fa";
import Modal from "./Modal";
import { useAuth } from "../../context/AuthContext";

const blank = {
  fullName: "",
  email: "",
  rollNo: "",
  umis: "",
  department: "",
  year: "",
  section: "",
  phone: "",
};

export default function StudentRegistrationModal({ open, onClose, title, subtitle, onSubmit, loading = false }) {
  const { user } = useAuth();
  const [form, setForm] = useState(blank);

  useEffect(() => {
    if (open) {
      setForm({
        ...blank,
        fullName: user?.name || "",
        email: user?.email || "",
        department: user?.department || "",
        year: user?.year || "",
        phone: user?.phone || "",
      });
    }
  }, [open, user]);

  const update = (key, value) => setForm((current) => ({ ...current, [key]: value }));

  const submit = async (event) => {
    event.preventDefault();
    await onSubmit(form);
  };

  return (
    <Modal open={open} onClose={() => !loading && onClose()} title={title || "Student Registration"} wide>
      <div className="mb-5 rounded-2xl bg-gradient-to-r from-blue-50 via-white to-cyan-50 p-4">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white shadow-lg shadow-blue-600/20">
            <FaUserGraduate />
          </div>
          <div>
            <p className="font-extrabold text-slate-800">Student details are required</p>
            <p className="mt-1 text-sm leading-6 text-slate-500">
              {subtitle || "These details will be saved with your club or event registration in MongoDB."}
            </p>
          </div>
        </div>
      </div>

      <form onSubmit={submit} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Full Name" value={form.fullName} onChange={(v) => update("fullName", v)} required />
          <Field label="College Email" value={form.email} onChange={(v) => update("email", v)} required type="email" />
          <Field label="Roll Number" value={form.rollNo} onChange={(v) => update("rollNo", v)} required />
          <Field label="UMIS Number" value={form.umis} onChange={(v) => update("umis", v)} required />
          <Field label="Department" value={form.department} onChange={(v) => update("department", v)} required />
          <Field label="Year" value={form.year} onChange={(v) => update("year", v)} required placeholder="e.g. 2nd Year" />
          <Field label="Section" value={form.section} onChange={(v) => update("section", v)} placeholder="e.g. A" />
          <Field label="Phone Number" value={form.phone} onChange={(v) => update("phone", v)} required type="tel" />
        </div>

        <div className="rounded-xl border border-emerald-100 bg-emerald-50 p-3 text-sm font-semibold text-emerald-700">
          <FaCheckCircle className="mr-2 inline" />
          Your registration will be linked to your CampusConnect account.
        </div>

        <button
          disabled={loading}
          className="w-full rounded-xl bg-gradient-to-r from-blue-600 to-cyan-600 py-3.5 font-extrabold text-white shadow-lg shadow-blue-600/20 transition hover:-translate-y-0.5 hover:from-blue-700 hover:to-cyan-700 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? "Saving Registration..." : "Confirm Registration"}
        </button>
      </form>
    </Modal>
  );
}

function Field({ label, value, onChange, required, type = "text", placeholder = "" }) {
  return (
    <label className="block">
      <span className="mb-1.5 block text-sm font-extrabold text-slate-700">{label}</span>
      <input
        required={required}
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(event) => onChange(event.target.value)}
        className="w-full rounded-xl border border-slate-200 bg-white px-3.5 py-3 outline-none transition focus:border-blue-500 focus:ring-4 focus:ring-blue-50"
      />
    </label>
  );
}
