import React from "react";

export default function Avatar({ name = "KIOT User", image = "", size = "h-10 w-10", textSize = "text-sm", onClick, title }) {
  const initial = name.trim().charAt(0).toUpperCase() || "K";
  const content = image ? <img src={image} alt={name} className="h-full w-full object-cover" onError={(e) => { e.currentTarget.style.display = "none"; }} /> : <span className={`${textSize} font-black text-white`}>{initial}</span>;
  return (
    <button type="button" onClick={onClick} title={title || name} className={`${size} flex shrink-0 items-center justify-center overflow-hidden rounded-full bg-gradient-to-br from-blue-700 via-indigo-600 to-cyan-500 shadow-md ring-2 ring-blue-100 transition hover:scale-105 focus:outline-none focus:ring-4 focus:ring-blue-100`}>
      {content}
    </button>
  );
}
