import React from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { FaHome, FaUser, FaTrophy, FaUsers, FaCalendarAlt, FaBullhorn, FaBell, FaUserShield, FaTimes, FaChartLine, FaBook, FaUserFriends, FaChalkboardTeacher, FaSearch, FaMapMarkedAlt, FaFileAlt, FaClipboardList } from "react-icons/fa";
import { useAuth } from "../../context/AuthContext";
import Avatar from "./Avatar";

const links = [["/dashboard","Dashboard",FaHome],["/profile","My Profile",FaUser],["/achievements","Achievements",FaTrophy],["/clubs","Clubs",FaUsers],["/events","Events",FaCalendarAlt],["/announcements","Announcements",FaBullhorn],["/circulars","Circulars",FaFileAlt],["/notifications","Notifications",FaBell],["/resources","Resource Sharing",FaBook],["/connect","Senior-Junior Connect",FaUserFriends],["/staff","Staff Directory",FaChalkboardTeacher],["/search","Advanced Search",FaSearch],["/campus-map","Campus Map",FaMapMarkedAlt]];

export default function Sidebar({ open, setOpen }) {
  const { user } = useAuth();
  const nav = useNavigate();
  const extra = user?.role === "super_admin" ? [["/users","Student & Staff Management",FaUserShield],["/dashboard","Analytics",FaChartLine]] : user?.role === "faculty" ? [["/club-members","Club Registered Members",FaClipboardList]] : [];
  const all = [...links, ...extra];
  return <aside className={`${open ? "translate-x-0" : "-translate-x-full"} fixed inset-y-0 left-0 z-40 w-[280px] bg-[#061633] text-white transition-transform md:static md:translate-x-0`}>
    <div className="flex h-full flex-col">
      <div className="relative overflow-hidden border-b border-white/10 bg-gradient-to-br from-blue-700 via-indigo-700 to-cyan-600 px-5 pb-5 pt-5">
        <div className="absolute -right-12 -top-12 h-36 w-36 rounded-full bg-white/10" />
        <button className="absolute right-3 top-3 rounded-lg bg-white/10 p-2 md:hidden" onClick={() => setOpen(false)}><FaTimes /></button>
        <button onClick={() => nav("/dashboard")} className="relative flex w-full items-center gap-3 text-left">
          <img src="/assets/college-logo.svg" className="h-12 w-12 rounded-2xl bg-white object-contain p-1 shadow-lg" alt="KIOT" />
          <div><div className="text-lg font-black">CampusConnect</div><div className="text-[11px] font-semibold text-blue-100">Knowledge Institute of Technology</div><div className="mt-1 text-[9px] font-black tracking-[.18em] text-cyan-100">KIOT COMMUNITY</div></div>
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-4 scrollbar-thin"><p className="mb-3 px-3 text-[10px] font-black uppercase tracking-[.2em] text-slate-500">Main Menu</p><nav className="space-y-1.5">{all.map(([to,label,Icon])=><NavLink key={`${to}-${label}`} onClick={() => setOpen(false)} to={to} className={({isActive}) => `group flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-bold transition ${isActive ? "bg-gradient-to-r from-blue-600 to-cyan-600 text-white shadow-lg shadow-blue-950/30" : "text-slate-300 hover:bg-white/10 hover:text-white"}`}><Icon className="text-[15px]" />{label}</NavLink>)}</nav></div>
      <div className="border-t border-white/10 p-4"><button onClick={() => nav("/profile")} className="flex w-full items-center gap-3 rounded-2xl bg-white/5 p-3 text-left hover:bg-white/10"><Avatar name={user?.name || "KIOT User"} image={user?.profileImage || ""} size="h-10 w-10" /><div className="min-w-0"><div className="truncate text-sm font-black">{user?.name || "KIOT User"}</div><div className="mt-0.5 text-xs capitalize text-cyan-300">{user?.role?.replace("_", " ")}</div></div></button></div>
    </div>
  </aside>;
}
