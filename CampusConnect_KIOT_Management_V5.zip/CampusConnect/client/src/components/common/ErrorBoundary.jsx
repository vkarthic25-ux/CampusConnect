import React from "react";

export default class ErrorBoundary extends React.Component {
  constructor(props) { super(props); this.state = { hasError: false, error: null }; }
  static getDerivedStateFromError(error) { return { hasError: true, error }; }
  componentDidCatch(error, info) { console.error("CampusConnect page error", error, info); }
  render() {
    if (!this.state.hasError) return this.props.children;
    return (
      <div className="mx-auto max-w-3xl rounded-3xl border border-red-200 bg-white p-8 text-center shadow-xl">
        <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-red-50 text-2xl font-black text-red-600">!</div>
        <h2 className="mt-4 text-2xl font-black text-slate-900">This page could not be displayed</h2>
        <p className="mt-2 text-sm text-slate-500">The rest of CampusConnect is still available. Refresh this page or open another tab.</p>
        <button onClick={() => window.location.reload()} className="mt-5 rounded-xl bg-blue-600 px-5 py-3 font-black text-white">Refresh Page</button>
        {this.state.error?.message && <p className="mt-4 rounded-xl bg-slate-50 p-3 text-left text-xs text-slate-500">{this.state.error.message}</p>}
      </div>
    );
  }
}
