import React from "react";
import { FaBars, FaSignOutAlt, FaSearch, FaBell, FaChevronDown } from "react-icons/fa";
import { useAuth } from "../../context/AuthContext";
import { useNavigate } from "react-router-dom";
import Avatar from "./Avatar";

export default function Navbar({ setSidebarOpen }) {
  const { user, logout } = useAuth();
  const nav = useNavigate();

  return (
    <header className="sticky top-0 z-30 flex min-h-[78px] items-center justify-between border-b border-slate-200 bg-white/95 px-4 shadow-sm backdrop-blur-xl sm:px-6">
      <div className="flex items-center gap-3">
        <button className="rounded-xl border border-slate-200 p-2.5 text-slate-700 md:hidden" onClick={() => setSidebarOpen(true)}><FaBars /></button>
        <button onClick={() => nav("/dashboard")} className="hidden items-center gap-2 sm:flex">
          <img src="/assets/college-logo.svg" alt="KIOT" className="h-10 w-10 rounded-xl shadow-sm" />
          <div className="text-left"><p className="text-base font-black text-blue-950">CampusConnect</p><p className="text-[10px] font-bold uppercase tracking-wider text-slate-400">KIOT Community Portal</p></div>
        </button>
        <div className="sm:hidden"><p className="text-base font-black text-blue-950">CampusConnect</p><p className="text-[10px] font-bold text-slate-400">KIOT</p></div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <div className="hidden items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 md:flex"><FaSearch className="text-slate-400" /><input className="w-48 bg-transparent text-sm font-semibold outline-none" placeholder="Search campus..." /></div>
        <button onClick={() => nav("/notifications")} className="relative rounded-xl border border-slate-200 p-2.5 text-slate-600 hover:bg-slate-50"><FaBell /><span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-red-500" /></button>
        <button onClick={() => nav("/profile")} className="group flex items-center gap-2 rounded-2xl p-1.5 pr-2 hover:bg-slate-50">
          <Avatar name={user?.name || "KIOT User"} image={user?.profileImage || ""} size="h-10 w-10" title="Open My Profile" />
          <span className="hidden text-left sm:block"><span className="block text-sm font-black text-slate-800">{user?.name || "Student"}</span><span className="block text-[11px] font-bold capitalize text-slate-400">{user?.role?.replace("_", " ")}</span></span>
          <FaChevronDown className="hidden text-xs text-slate-400 sm:block" />
        </button>
        <button onClick={logout} title="Logout" className="rounded-xl p-2.5 text-slate-500 hover:bg-red-50 hover:text-red-600"><FaSignOutAlt /></button>
      </div>
    </header>
  );
}
