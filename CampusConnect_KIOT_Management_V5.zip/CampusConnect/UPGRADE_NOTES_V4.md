CampusConnect V4 updates

1. Super Admin now has an explicit Faculty Account option. Faculty accounts use Staff Login automatically and appear in Staff Directory with their department.
2. Staff Directory supports server-side search and filters by department and designation.
3. Super Admin can send notifications to all users, students only, staff/faculty only, and optionally a selected department. Notifications are stored in MongoDB.
4. Circular visibility was fixed: Super Admin sees all circulars; students/staff see circulars matching audience and department. Newly created/updated circulars are inserted immediately into the page and refreshed from the API.

Setup:
cd CampusConnect\server
npm install
npm run seed
npm run dev

cd CampusConnect\client
npm install
npm run dev
