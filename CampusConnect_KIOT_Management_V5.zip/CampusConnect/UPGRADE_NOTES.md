# CampusConnect KIOT Feature Upgrade

This version adds:

- Private club chat for club members, club admins and faculty in-charge.
- Resource Sharing for notes, PDFs and study documents. Files are stored in MongoDB as base64 data with an 8 MB upload limit.
- Senior-Junior Connect with department, year, subjects and skills filters.
- Advanced Search for students/staff, clubs and events with multiple filters.
- Staff Directory with faculty and club-admin details.
- Campus Map with a schematic KIOT block/facility view.
- Student/Staff account type shown automatically from the database role after login.
- Super Admin can create Student, Faculty/Staff and Club Admin accounts using KIOT email addresses.
- User profiles now store department, year, section, roll number, UMIS, batch, subjects, skills, bio, designation, qualification and employee ID.
- Login activity stores lastLoginAt and loginCount.
- Larger typography and clearer campus background.
- Clickable profile avatar continues to open My Profile and falls back to the first letter of the user's name.

## Setup

### Server

```powershell
cd "CampusConnect\server"
npm install
npm run seed
npm run dev
```

### Client

```powershell
cd "CampusConnect\client"
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:5000

## Seed accounts

- Super Admin: admin@kiot.ac.in / Admin@123
- Faculty: faculty@kiot.ac.in / Faculty@123
- Club Admin: clubadmin@kiot.ac.in / ClubAdmin@123
- Student: student@kiot.ac.in / Student@123
