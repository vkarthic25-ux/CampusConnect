# CampusConnect KIOT – Chat, Login Type & Illustrated Map Update

## Added in this version

### 1. Senior–Junior Connect is now a WhatsApp-style group chat
- Department-based peer groups.
- Group list on the left and chat window on the right.
- Student members can join their department group.
- Message sender name, year and department are shown.
- Chat refreshes automatically every 4 seconds.
- MongoDB stores groups, members and messages.
- Subjects and skills remain part of the student profile/network.

### 2. Student / Staff login selection
- `/login` now asks the user to choose **Student** or **Staff** before sign-in.
- Direct routes are also available:
  - `/student-login`
  - `/staff-login`
- Backend checks the selected account type against the account's database role.
- Student accounts open `/student-home`.
- Faculty, Club Admin and Super Admin accounts open `/staff-home`.
- User documents now contain `accountType: student | staff`.
- Every successful login is stored in `LoginActivity` with account type, role, time and request metadata.
- `lastLoginAt` and `loginCount` are also updated on the User document.

### 3. Admin-created accounts
- Super Admin-created Student / Faculty / Club Admin accounts are saved with the correct `accountType`.
- Passwords are hashed before being stored.
- Changing a user's role also synchronizes `accountType`.
- Staff accounts can therefore use Staff Login immediately after creation.

### 4. Illustrated campus map
- Replaced the previous plain block diagram with an illustrated orientation map.
- Uses numbered building markers, roads, lawns, trees, gates, sports field and an illustrated-building visual treatment inspired by the reference image supplied for this project.
- Includes A, B, C, D, E, MBA blocks, Central Library, Open Auditorium, Security Gates, Main Gate, ATM/Common Services and sports/facility zones.
- Click a numbered building or search it in the guide panel to see details.
- This remains an orientation illustration, not a surveyed navigation map.

## Setup

### Server
```powershell
cd "CampusConnect\server"
npm install
npm run seed
npm run dev
```

### Client
```powershell
cd "CampusConnect\client"
npm install
npm run dev
```

Frontend: http://localhost:5173
Backend: http://localhost:5000

## Demo accounts
- Student: `student@kiot.ac.in` / `Student@123`
- Faculty: `faculty@kiot.ac.in` / `Faculty@123`
- Club Admin: `clubadmin@kiot.ac.in` / `ClubAdmin@123`
- Super Admin: `admin@kiot.ac.in` / `Admin@123`

For a fresh database, run `npm run seed` after MongoDB is running.

## V3 updates
- Removed the Discussions page and removed it from the sidebar/navigation.
- Added a Circulars tab. Faculty, Club Admin and Super Admin can publish, edit and delete circulars. Students and staff can view permitted circulars and download attachments.
- Fixed Events "View Details". It now opens a real event-detail modal with event date, time, venue, organizing club, faculty coordinator and registered student records.
- Expanded Super Admin User Management into full student/staff CRUD: create, update, delete, activate/deactivate, academic/work details and optional password change.
- Added Staff/Faculty "Club Registered Members" workspace. Faculty can see registration records for clubs where they are faculty in-charge and export the records to CSV.
- Student/Staff login routing remains automatic from the database role: student -> student workspace, faculty/club admin/super admin -> staff workspace. Successful logins continue to be stored in MongoDB.
